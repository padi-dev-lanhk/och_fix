<?php 
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class ova_room_search extends Widget_Base{

	public function get_name() {
		return 'ova_room_search';
	}

	public function get_title() {
		return __( 'Room Search', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-shortcode';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls(){

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Booking', 'ova-framework')
			]
		);
			$this->add_control(
				'style_room_search',
				[
					'label'   => __('Style Search','ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'style1',
					'options' => [
						'style1' => __('Style1','ova-framework'),
						'style2' => __('Style2','ova-framework'),
						'style3' => __('Style3','ova-framework'),
						'style4' => __('Style4','ova-framework'),
						'style5' => __('Style5','ova-framework'),
						'style6' => __('Style6','ova-framework')
 					]
				]
			);

			$this->add_control(
				'show_checkin',
				[
					'label'   => __('Show Check-In', 'ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true'  => __('Yes', 'ova-framework'),
						'false' => __('No', 'ova-framework') 
					]
				]
			);

			$this->add_control(
				'show_checkout',
				[
					'label'   => __('Show Check-Out', 'ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true'  => __('Yes', 'ova-framework'),
						'false' => __('No', 'ova-framework')
					]

				]
			);

			$this->add_control(
				'show_adults',
				[
					'label'   => __('Show Adults', 'ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true'  => __('Yes', 'ova-framework'),
						'false' => __('No', 'ova-framework')
					]
				]
			);

			$this->add_control(
				'show_childrens',
				[
					'label'   => __('Show Childrens','ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true'  => __('Yes','ova-framework'),
						'false' => __('No','ova-framework')
					]
				]
			);

			$this->add_control(
				'show_room',
				[
					'label'   => __('Show Rooms','ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true'  => __('Yes','ova-framework'),
						'false' => __('No', 'ova-framework')
					],
					'condition' => [
						'style_room_search' => ['style3','style5','style6']
					]
				]
			);

			$this->add_control(
				'show_night_ipad',
				[
					'label'   => __('Show Night In: ipad,mobile','ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'false',
					'options' => [
						'true'  => __('Yes','ova-framework'),
						'false' => __('No','ova-framework')	
					],
					'condition' => [
						'style_room_search' => ['style3','style5','style6']
					]
				]
			);

			$this->add_control(
				'required_adults',
				[
					'label'   => __('Required Input: Adults','ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true'  => __('Yes','ova-framework'),
						'false' => __('No','ova-framework')
					]
 				]
			);

			$this->add_control(
				'required_childrens',
				[
					'label'   => __('Required Input: Childrens','ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true'  => __('Yes','ova-framework'),
						'false' => __('No','ova-framework')
					]
				]
			);

			$this->add_control(
				'required_room',
				[
					'label'   => __('Required Input: Room', 'ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true'  => __('Yes','ova-framework'),
						'false' => __('No','ova-framework')
					],
					'condition' => [
						'style_room_search' => ['style3','style5','style6']
					]
				]
			);

			$this->add_control(
				'max_adults',
				[
					'label'   => __('Max Adults','ova-framework'),
					'type'    => Controls_Manager::NUMBER,
					'default' => 5,
					'min'     => 1
				]
			);

			$this->add_control(
				'max_childrens',
				[
					'label'   => __('Max Childrens','ova-framework'),
					'type'    => Controls_Manager::NUMBER,
					'default' => 10,
					'min'     => 1
				]
			);

			$this->add_control(
				'max_room',
				[
					'label'   => __('Max Rooms','ova-framework'),
					'type'    => Controls_Manager::NUMBER,
					'default' => 10,
					'min'     => 1
				]
			);

			$this->add_control(
				'search_button_text',
				[
					'label' => __('Button Text','ova-framework'),
					'type' => Controls_Manager::TEXT,
					'default' => __('Check Availability','ova-framework'),
					'placeholder' => __( 'Enter your text', 'ova-framework' ),
				]
			);

		$this->end_controls_section();

		// Style section

		$this->start_controls_section(
			'section_search_background',
			[
				'label' => __('Form Search','ova-framework'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
			$this->add_control(
				'form_search_background',
				[
					'label'     => __('Form search background','ova-framework'),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .ova_search .ovahotel_search .wrap-check-form' => 'background: {{VALUE}};'
					]
				]
			);

			$this->add_control(
				'form_search_label_color',
				[
					'label'     => __('Label Color','ova-framework'),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .ova_search .ovahotel_search .wrap-check-form .hotel_field label' => 'color: {{VALUE}};'
					]
				]
			);

			$this->add_control(
				'form_search_date_color',
				[
					'label'     => __('Yeae/Moth/Date Color','ova-framework'),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .ovahotel_search .wrap-check-form .hotel_field .hotel_field_date .show_date .day_digit,
						{{WRAPPER}} .ova_search .ovahotel_search .wrap-check-form .hotel_field .show_date .month_year .m_y' => 'color: {{VALUE}} !important;'
					]
				]
			);

			$this->add_control(
				'form_search_day_color',
				[
					'label'     => __('Day Color','ova-framework'),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .ovahotel_search .wrap-check-form .hotel_field .hotel_field_date .show_date .month_year .day_name' => 'color: {{VALUE}} !important;'
					]
				]
			);

			$this->add_control(
				'form_search_number_color',
				[
					'label'     => __('Numer Search Color','ova-framework'),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .ova_search .style6.ovahotel_search .wrap-check-form .hotel_field .select2-container--default .select2-selection__rendered' => 'color: {{VALUE}} !important;'
					]
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_search_background',
			[
				'label' => __('Button Search','ova-framework'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
			$this->add_control(
				'button_search_color',
				[
					'label'     => __('Button Color','ova-framework'),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .ova_search .ovahotel_search .wrap-check-form .hotel_field.btn_search .btn_tran' => 'color: {{VALUE}};'
					]
				]
			);

			$this->add_control(
				'button_search_color_hover',
				[
					'label'     => __('Button Color Hover','ova-framework'),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .ova_search .ovahotel_search .wrap-check-form .hotel_field.btn_search .btn_tran:hover' => 'color: {{VALUE}};'
					]
				]
			);

			$this->add_control(
				'background_button',
				 [
				 	'label' => __('Button Background ','ova-framework'),
				 	'type'  => Controls_Manager::COLOR,
				 	'default' => '',
				 	'selectors' => [
				 		'{{WRAPPER}} .ova_search .ovahotel_search .wrap-check-form .hotel_field.btn_search .btn_tran' => 'background: {{VALUE}} !important;'
				 	]
				 ]
			);

			$this->add_control(
				'background_button_hover',
				[
					'label' => __('Button Background Hover','ova-framework'),
					'type'  => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .ova_search .ovahotel_search .wrap-check-form .hotel_field.btn_search .btn_tran:hover' => 'background: {{VALUE}} !important;'
					]
				]
			);


		$this->end_controls_section();


	}

	protected function render(){

		$settings = $this->get_settings();
	?>
		<div class="ova_search">
			<div class="container">
				<?php

					$style = $settings['style_room_search'];
					$button_text = $settings['search_button_text'];

					// Show/Hide field in Form
					$ova_search_show_check_in  = $settings['show_checkin'];
					$ova_search_show_check_out = $settings['show_checkout'];
					$ova_search_show_adults    = $settings['show_adults'];
					$ova_search_show_childrens = $settings['show_childrens'];
					
					if( $settings['style_room_search'] == 'style3' || $settings['style_room_search'] == 'style5' || $settings['style_room_search'] == 'style6'){
						$show_night_ipad = $settings['show_night_ipad'];
						$ova_search_show_rooms     = $settings['show_room'];
					}else{
						$show_night_ipad = 'false';
						$ova_search_show_rooms = 'false';
					}

					if( $settings['show_night_ipad'] == 'true' && $settings['style_room_search'] == 'style5' ||  $settings['show_night_ipad'] == 'true' && $settings['style_room_search'] == 'style6'){
						$class_btn = 'seach_sc';
					}else{
						$class_btn = '';
					}
					//$show_night_ipad           = $settings['show_night_ipad'];
						
					$ova_max_adults    =  intval( $settings['max_adults']) ;
					$ova_max_childrens =  intval( $settings['max_childrens']) ;
					$ova_max_rooms     = intval( $settings['max_room']) ;


					// Check Field requirement

					$search_is_req_adults    = $settings['required_adults'] == 'true' ? 'required' : '';
					$search_is_req_childrens = $settings['required_childrens'] == 'true' ? 'required' : '';
					$search_is_req_rooms     = $settings['required_room'] == 'true' ? 'required' : '';
																			

					echo do_shortcode( '[ovahotel_search class=" '.$style.' '.$class_btn.' elementor_sc" show_check_in="'.$ova_search_show_check_in.'" show_check_out="'.$ova_search_show_check_out.'" show_adults="'.$ova_search_show_adults.'" show_childrens="'.$ova_search_show_childrens.'" show_rooms="'.$ova_search_show_rooms.'" show_night="false" show_night_ipad="'.$show_night_ipad.'" max_adults="'.$ova_max_adults.'" max_childrents="'.$ova_max_childrens.'" max_room="'.$ova_max_rooms.'" req_input_adults="'.$search_is_req_adults.'" req_input_childrens="'.$search_is_req_childrens.'" req_input_rooms="'.$search_is_req_rooms.'"
						button_text="'.esc_html__( $button_text ).'" /]'); ?>
			</div>	
		</div>

	<?php } 

}