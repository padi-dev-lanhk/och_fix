<?php
namespace ova_framework\Widgets;
use Elementor;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class ova_contact_us extends Widget_Base {

	public function get_name() {
		return 'ova_contact_us';
	}

	public function get_title() {
		return __( 'Contact Us', 'ova-framework' );
	}

	public function get_icon() {
		return 'fa fa-mobile';
	}

	public function get_categories() {
		return [ 'hf' ];
	}

	public function get_keywords() {
		return [ 'image', 'photo', 'visual' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_phone_number',
			[
				'label' => __( 'Contact Us', 'ova-framework' ),
			]
		);
			$this->add_control(
				'text_contact',
				[
					'label' => __( 'Text Contact', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 3,
					'default' => __( 'CALL US NOW: ', 'ova-framework' ),
					'placeholder' => __( 'Type your text here', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'text_typography',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} span',
				]
			);

			$this->add_control(
				'text_color',
				[
					'label' => __( 'Title Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} span' => 'color: {{VALUE}}',
					],
				]
			);


			$this->add_control(
				'phone_number',
				[
					'label' => __( 'Phone Numbers', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'placeholder' => __( 'Type your number phone here', 'ova-framework' ),
					'label_block' => true,
					'default' => __( '(+88) 12 345 6789', 'ova-framework' ),
					'separator' => 'before',
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'number_typography',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .number',
				]
			);

			$this->add_control(
				'numbers_color',
				[
					'label' => __( 'Numbers Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .number' => 'color: {{VALUE}}',
					],
				]
			);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();
		$html = '';
		
		$html .= '<div class="ova_contact_us">';
			$html .=	'<span>'.$settings['text_contact'].' </span> <span class ="number">'.$settings['phone_number'].'</span>';
		$html .= '</div>';;
		echo $html;
	}

	
}

