<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_service_box extends Widget_Base {

	public function get_name() {
		return 'ova_service_box';
	}

	public function get_title() {
		return __( 'Service Box', 'ova-framework' );
	}

	public function get_icon() {
		return 'fa fa-archive';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);
			$this->add_control(
				'change_position',
				[
					'label' => __( 'Change Position', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
				]
			);

			$this->add_control(
				'image',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
				]
			);

			$this->add_control(
				'link',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '#',
						'is_external' => false,
						'nofollow' => false,
					],
				]
			);

			$this->add_control(
				'text_alpha',
				[
					'label' => __( 'Text Alpha', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'A', 'ova-framework' ),
				]
			);


			$this->add_control(
				'title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'Comfortable', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
				]
			);

			$this->add_control(
				'description',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
				]
			);


			$this->add_control(
				'text_button',
				[
					'label' => __( 'Text Button', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Explore More', 'ova-framework' ),
				]
			);

		$this->end_controls_section();

		/*******************************************************************************
						TAB STYLE SERVICE BOX
		********************************************************************************/

		/*************  section controll text background *******************/

		$this->start_controls_section(
			'section_text_background',
			[
				'label' => __( 'Text Background', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,

			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'text_background',
					'selector' => '{{WRAPPER}} .ova-service-box .content .text-alpha',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_text_background',
				[
					'label' => __( 'Color Text Background', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .text-alpha' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'position_x_text_background',
				[
					'label' => __( 'Position X', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => -100,
							'max' => 300,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .text-alpha' => 'right: calc({{SIZE}}{{UNIT}});',
					],
				]
			);

			$this->add_control(
				'position_y_text_background',
				[
					'label' => __( 'Position Y', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => -300,
							'max' => 300,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .text-alpha' => 'transform: translateY(calc(-50% - {{SIZE}}{{UNIT}}));',
					],
				]
			);

			$this->add_control(
				'font_size_text_background',
				[
					'label' => __( 'Font Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 500,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .text-alpha' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll text background ###############################

		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .ova-service-box .content .title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_title_hover',
				[
					'label' => __( 'Color Title Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .title a:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################

		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography',
					'selector' => '{{WRAPPER}} .ova-service-box .content .desc',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################

		/*************  section controll read more. *******************/

		$this->start_controls_section(
			'section_readmore',
			[
				'label' => __( 'Text View', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'text_view_typography',
					'selector' => '{{WRAPPER}} .ova-service-box .content .read-more',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_text_view',
				[
					'label' => __( 'Color Text View', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .read-more' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_text_view_hover',
				[
					'label' => __( 'Color Text View Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .read-more:hover' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color_text_view',
				[
					'label' => __( 'Background Color Text View', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .read-more' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color_text_view_hover',
				[
					'label' => __( 'Background Color Text View Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .read-more:hover' => 'background-color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_text_view',
				[
					'label' => __( 'Margin Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_text_view',
				[
					'label' => __( 'Padding Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll read more ###############################


		/*************  section controll Background. *******************/

		$this->start_controls_section(
			'section_background',
			[
				'label' => __( 'Background', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	


			$this->add_control(
				'background_color',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content' => 'background-color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'margin_content',
				[
					'label' => __( 'Margin Content', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => -200,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-box .content' => 'margin-left: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .ova-service-box.change-position .content' => 'margin-right: {{SIZE}}{{UNIT}};margin-left: 0px',
					],
				]
			);



		$this->end_controls_section();
		#################### section controll background  ###############################

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$change_position = $image = $link = $target = $text_alpha = $title = $descitpion = $text_button = "";
		$change_position = $settings['change_position'] === 'yes' ? ' change-position ' : '' ;
		$image = $settings['image']['url'];
		$link = $settings['link']['url'];
		$target = $settings['link']['is_external'] ? " target='_blank' " : '' ;
		$text_alpha = $settings['text_alpha'];
		$title = $settings['title'];
		$description = $settings['description'];
		$text_button = $settings['text_button'];

		?>

		<div class="ova-service-box  <?php echo $change_position ?> ">
			<div class="image-box" style="background-image: url(<?php echo $image ?>)">
				<a href=""></a>
			</div>
			<div class="content">
				<p class="text-alpha"><?php echo $text_alpha ?></p>
				<h3 class="title"><a class="second_font" href="<?php echo $link ?>" <?php echo $target ?> ><?php echo $title ?></a></h3>
				<p class="desc"><?php echo $description ?></p>
				<a href="<?php echo $link ?>" class="read-more" <?php echo $target ?>><?php echo $text_button ?></a>
			</div>
		</div>
		<?php
	}
}
