<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor tabs widget.
 *
 * Elementor widget that displays vertical or horizontal tabs with different
 * pieces of content.
 *
 * @since 1.0.0
 */
class ova_service_tab extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve tabs widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'ova_service_tab';
	}

	public function get_title() {
		return __( 'Service Tab', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-tabs';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_tabs',
			[
				'label' => __( 'Tabs', 'ova-framework' ),
			]
		);

		$this->add_control(
			'version_service',
			[
				'label' => __( 'Choose Service Tab Version', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'service_ver_1',
				'options' => [
					'service_ver_1' => __( 'Sevice Version 1', 'ova-framework' ),
					'service_ver_2' => __( 'Sevice Version 2', 'ova-framework' ),
				],
			]
		);

		/*****************************************************************
						REPEAT SERVICE VERSION 1
		*****************************************************************/

		$repeater_ver_1 = new Repeater();

		$repeater_ver_1->add_control(
			'tab_title',
			[
				'label' => __( 'Title Tab', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Tab Title', 'ova-framework' ),
				'placeholder' => __( 'Tab Title', 'ova-framework' ),
				'label_block' => true,
				
			]
		);

		$repeater_ver_1->add_control(
			'tab_icon',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'default' => __( 'flaticon-dinner', 'ova-framework' ),
				'placeholder' => __( 'Tab Content', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				
			]
		);

		$repeater_ver_1->add_control(
			'tab_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'default' => __( 'Tab Content', 'ova-framework' ),
				'description' => __( 'Example: [service_tab_ul_ver_1][service_tab_ver_1_li title="Spicy Food" num_col="2" link="#" image_link="PATH_IMAGE"  desc="Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore" price="$15"][/service_tab_ver_1_li][/service_tab_ul_ver_1]','ova-framework' ),
				'placeholder' => __( 'Tab Content', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => 30,
				
			]
		);

		$this->add_control(
			'tabs_ver_1',
			[
				'label' => __( 'Tabs Items', 'ova-framework' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater_ver_1->get_controls(),
				'title_field' => '{{{ tab_title }}}',
				'condition' => [
					'version_service' => 'service_ver_1',
				],
			]
		);

		#################################     END REPEAT SERVICE VERSION 1 ############################################




		/*****************************************************************
						REPEAT SERVICE VERSION 2
		*****************************************************************/

		$repeater_ver_2 = new Repeater();

		$repeater_ver_2->add_control(
			'tab_title',
			[
				'label' => __( 'Title Tab', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Tab Title', 'ova-framework' ),
				'placeholder' => __( 'Tab Title', 'ova-framework' ),
				'label_block' => true,
				
			]
		);

		$repeater_ver_2->add_control(
			'tab_icon',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'default' => __( 'flaticon-dinner', 'ova-framework' ),
				'placeholder' => __( 'Tab Content', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				
			]
		);

		$repeater_ver_2->add_control(
			'tab_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'default' => __( 'Tab Content', 'ova-framework' ),
				'placeholder' => __( 'Tab Content', 'ova-framework' ),
				'description' => __( 'Example: [service_tab_ul_ver_2][service_tab_ver_2_li title="Spicy Food" num_col="4" link="#" image_link="PATH_IMAGE"  desc="Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore" price="$15"][/service_tab_ver_2_li][/service_tab_ul_ver_2]','ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => 30,
				
			]
		);

		$this->add_control(
			'tabs_ver_2',
			[
				'label' => __( 'Tabs Items', 'ova-framework' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater_ver_2->get_controls(),
				'title_field' => '{{{ tab_title }}}',
				'condition' => [
					'version_service' => 'service_ver_2',
				],
			]
		);

		#################################     END REPEAT SERVICE VERSION 2 ############################################


		$this->end_controls_section();
		//end section content


		/*******************************************************************************
						TAB STYLE SERVICE VERSION 1
		********************************************************************************/

		/*************  section controll icon. *******************/

		$this->start_controls_section(
			'icon_service_tab_ver_1',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_1',
				],
			]
		);	

			$this->add_control(
				'color_icon_service_tab_ver_1',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title i:before' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_icon_service_tab_ver_1',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title:hover i:before,  {{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title.active i:before ' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon_service_tab_ver_1',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 150,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_icon_service_tab_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_icon_service_tab_ver_1',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll icon ###############################



		/*************  section controll title tab. *******************/

		$this->start_controls_section(
			'section_title_tab_service_tab_ver_1',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_tab_typography_service_tab_ver_1',
					'selector' => '{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_tab_service_tab_ver_1',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_title_tab_service_tab_ver_1',
				[
					'label' => __( 'Color Hover Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title:hover a' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title_tab_service_tab_ver_1',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_tab_service_tab_ver_1',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title tab ###############################


		/*************  section controll image thumbnail *******************/

		$this->start_controls_section(
			'section_image_thumbnail_service_tab_ver_1',
			[
				'label' => __( 'Image Thumbnail', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_1',
				],
			]
		);	

			$this->add_control(
				'width_height_service_tab_ver_1',
				[
					'label' => __( 'Width And Height Image Thumbnail', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 50,
							'max' => 300,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .item-image' => 'flex-basis: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content' => 'flex-basis: calc(100% - {{SIZE}}{{UNIT}});',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll image thumbnail ###############################


		/*************  section controll title item. *******************/

		$this->start_controls_section(
			'section_title_item_service_tab_ver_1',
			[
				'label' => __( 'Titlte Item', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_tab_item_typography_service_tab_ver_1',
					'selector' => '{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div h3.title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_item_service_tab_ver_1',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000',
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div h3.title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_title_item_service_tab_ver_1',
				[
					'label' => __( 'Color Hover Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div h3.title a:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title_item_service_tab_ver_1',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div h3.title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_item_service_tab_ver_1',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div h3.title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title item ###############################


		/*************  section controll line title *******************/

		$this->start_controls_section(
			'section_line_title_service_tab_ver_1',
			[
				'label' => __( 'Line Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_1',
				],
			]
		);	

			$this->add_control(
				'color_line_title_service_tab_ver_1',
				[
					'label' => __( 'Color Line Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div:before' => 'border-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'line_title_type_service_tab_ver_1',
				[
					'label' => __( 'Type', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'dotted',
					'options' => [
						'dotted' => __( 'Dotted', 'ova-framework' ),
						'solid' => __( 'Solid', 'ova-framework' ),
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div:before' => 'border-style : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'line_title_width_service_tab_ver_1',
				[
					'label' => __( 'Width', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 10,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div:before' => 'border-width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'line_title_position_service_tab_ver_1',
				[
					'label' => __( 'Position', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div:before' => 'top: {{SIZE}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll line title ###############################


		/*************  section controll price *******************/

		$this->start_controls_section(
			'section_price_service_tab_ver_1',
			[
				'label' => __( 'Price', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'price_typography_service_tab_ver_1',
					'selector' => '{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div span.price',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_price_service_tab_ver_1',
				[
					'label' => __( 'Color Price', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div span.price' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_price_service_tab_ver_1',
				[
					'label' => __( 'Margin Price', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div span.price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_price_service_tab_ver_1',
				[
					'label' => __( 'Padding price', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content div span.price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll price ###############################


		/*************  section controll description *******************/

		$this->start_controls_section(
			'section_desc_service_tab_ver_1',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography_service_tab_ver_1',
					'selector' => '{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content p',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_service_tab_ver_1',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#6f6f6f',
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content p' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_service_tab_ver_1',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_service_tab_ver_1',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper .service-tab-content .item .content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll price ###############################


		/*******************************************************************************
						TAB STYLE SERVICE VERSION 2
		********************************************************************************/

		/*************  section controll icon ver 2. *******************/

		$this->start_controls_section(
			'icon_service_tab_ver_2',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_2',
				],
			]
		);	

			$this->add_control(
				'color_icon_service_tab_ver_2',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title i:before' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_icon_service_tab_ver_2',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title:hover i:before,  {{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title.active i:before ' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon_service_tab_ver_2',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 150,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_icon_service_tab_ver_2',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_icon_service_tab_ver_2',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll icon ver 2 ###############################


		/*************  section controll title tab. *******************/

		$this->start_controls_section(
			'section_title_tab_service_tab_ver_2',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_2',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_tab_typography_service_tab_ver_2',
					'selector' => '{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_tab_service_tab_ver_2',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_title_tab_service_tab_ver_2',
				[
					'label' => __( 'Color Hover Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title:hover a' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title_tab_service_tab_ver_2',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_tab_service_tab_ver_2',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-title-wrapper .service-tab-title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title tab ver 2 ###############################



		/*************  section controll image thumbnail *******************/

		$this->start_controls_section(
			'section_image_thumbnail_service_tab_ver_2',
			[
				'label' => __( 'Image Thumbnail', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_2',
				],
			]
		);	

			$this->add_control(
				'height_service_tab_ver_2',
				[
					'label' => __( 'Height Image', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 50,
							'max' => 500,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .item-image' => 'height: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll image thumbnail ###############################

		/*************  section controll price *******************/

		$this->start_controls_section(
			'section_price_service_tab_ver_2',
			[
				'label' => __( 'Price', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_2',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'price_typography_service_tab_ver_2',
					'selector' => '{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .item-image .price span',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_price_service_tab_ver_2',
				[
					'label' => __( 'Color Price', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .item-image .price span' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color_price_service_tab_ver_2',
				[
					'label' => __( 'Background Color Price', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .item-image .price span' => 'background-color : {{VALUE}};',
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .item-image .price span:after' => 'border-bottom-color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_price_service_tab_ver_2',
				[
					'label' => __( 'Margin Price', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .item-image .price span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_price_service_tab_ver_2',
				[
					'label' => __( 'Padding price', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .item-image .price span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll price ###############################


		/*************  section controll title item service version 2. *******************/

		$this->start_controls_section(
			'section_title_item_service_tab_ver_2',
			[
				'label' => __( 'Titlte Item', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => 'service_ver_2',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_tab_item_typography_service_tab_ver_2',
					'selector' => '{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .content h3.title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_item_service_tab_ver_2',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000',
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .content h3.title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_title_item_service_tab_ver_2',
				[
					'label' => __( 'Color Hover Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000',
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .content h3.title a:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title_item_service_tab_ver_2',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .content h3.title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_item_service_tab_ver_2',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-tabs-content-wrapper.service_ver_2 .service-tab-content .item .content h3.title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title item service version 2 ###############################


		##########################   END TAB STYLE SERVICE 2 ##################################


	}

	/**
	 * Render tabs widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$tabs = [];
		$setttings =  $this->get_settings_for_display();
		$version_service = $setttings['version_service'];

		switch ($version_service) {
			case "service_ver_1" : {
				$tabs = $this->get_settings_for_display( 'tabs_ver_1' );
				break;
			}
			case "service_ver_2" : {
				$tabs = $this->get_settings_for_display( 'tabs_ver_2' );
				break;
			}
		}

		$id_int = substr( $this->get_id_int(), 0, 3 );
		?>
		<div class="ova-service-tabs" role="tablist">
			<div class="ova-service-tabs-title-wrapper ">
				<?php
				foreach ( $tabs as $index => $item ) :
					$tab_count = $index + 1;
					$tab_title_setting_key = $this->get_repeater_setting_key( 'tab_title', 'tabs', $index );
					$this->add_render_attribute( $tab_title_setting_key, [
						'id' => $id_int . $tab_count,
						'class' => [ 'service-tab-title' ],
					] );
					?>
					<div <?php echo $this->get_render_attribute_string( $tab_title_setting_key ); ?>><i class='<?php echo $item['tab_icon']; ?>'></i><a class="second_font" href="javascript:void(0)"><?php echo $item['tab_title']; ?></a></div>
				<?php endforeach; ?>
			</div>
			<div class="ova-service-tabs-content-wrapper ">
				<?php
				foreach ( $tabs as $index => $item ) :
					$tab_count = $index + 1;
					$tab_content_setting_key = $this->get_repeater_setting_key( 'tab_content', 'tabs', $index );
					$this->add_render_attribute( $tab_content_setting_key, [
						'id' => 'service-tab-content-' . $id_int . $tab_count,
						'class' => [ 'service-tab-content'],
					] );
					?>
					<div <?php echo $this->get_render_attribute_string( $tab_content_setting_key ); ?>><?php echo do_shortcode( $item['tab_content'] ); ?></div>

				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}


	

}

