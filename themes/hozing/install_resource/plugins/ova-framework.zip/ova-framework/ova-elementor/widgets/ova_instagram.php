<?php
namespace ova_framework\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_instagram extends Widget_Base {

	public function get_name() {
		return 'ova_instagram';
	}

	public function get_title() {
		return __( 'Instagram', 'ova-framework' );
	}

	public function get_icon() {
		return ' fa fab fa-instagram';
	}

	public function get_categories() {
		return [ 'hf' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'token',
			[
				'label' => __( 'Token', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'description' => 'How to Get Instagram Access Token <a href="https://elfsight.com/blog/2016/05/how-to-get-instagram-access-token" target="_blank">Click Here</a>'
			]
		);

		$this->add_control(
			'height',
			[
				'label' => __( 'Height', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 30,
				'default' => 500,
			]
		);

		$this->add_control(
			'number_photo',
			[
				'label' => __( 'Number Photos', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 5,
				'default' => 15,
			]
		);

		$this->add_control(
			'overlay',
			[
				'label' => __( 'Overlay Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instagram .overlay' => 'background: {{VALUE}}',
				],
				'default' => 'rgba(0,0,0,0.7)',
			]
		);

		

		$this->add_control(
			'show_follow',
			[
				'label' => __( 'Show Follow', 'ova-framework' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'follow_style',
			[
				'label' => __( 'Follow', 'ova-framework' ),
				'tab' => \Elementor\Controls_Manager::HEADING,
				'conditions' => [
					'terms' => [
						[
							'name' => 'show_follow',
							'operator' => '!=',
							'value' => '',
						],
					],
				],
			]
		);

		$this->add_control(
			'follow_version',
			[
				'label' => _x( 'Follow', 'ova-framework' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => _x( 'Version 1', 'ova-framework' ),
					'version_2' => _x( 'Version 2', 'ova-framework' ),
				],
			]
		);

		$this->add_control(
			'icon_follow_style',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => __( 'Icon', 'elementor-pro' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'text_icon',
			[
				'label' => __( 'Social Icons', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'default' => 'fa fa-instagram',
			]
		);

		$this->add_control(
			'icon_follow_size',
			[
				'label' => __( 'Icon Size', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .follow .icon_follow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_follow_color',
			[
				'label'  => __( 'Icon Color', 'ova-framework' ),
				'type'   => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .follow .icon_follow' => 'color: {{VALUE}}',
				],
				'default' => '#b9a271',
			]
		);

		$this->add_responsive_control(
			'icon_follow_margin',
			[
				'label' => __( 'Margin', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .follow i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'show_follow',
							'operator' => '!=',
							'value' => '',
						],
					],
				],
			]
		);

		$this->add_control(
			'heading_title',
			[
				'type'      => \Elementor\Controls_Manager::HEADING,
				'label'     => __( 'Title', 'ova-framework' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'title',
			[
				'label' => __( 'Text', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Follow', 'ova-framework' ),
				'conditions' => [
					'terms' => [
						[
							'name' => 'show_follow',
							'operator' => '!=',
							'value' => '',
						],
					],
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => __( 'Color', 'ova-framework' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .follow .title' => 'color: {{VALUE}}',
				],
				'default' => '#020202',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .follow .title',
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label' => __( 'Margin', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .follow .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'show_follow',
							'operator' => '!=',
							'value' => '',
						],
					],
				],
			]
		);

		$this->add_control(
			'description_style',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => __( 'Description', 'ova-framework' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'description',
			[
				'label' => __( 'Text', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'on instagrams', 'ova-framework' ),
				'conditions' => [
					'terms' => [
						[
							'name' => 'show_follow',
							'operator' => '!=',
							'value' => '',
						],
					],
				],
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => __( 'Color', 'ova-framework' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .follow .description' => 'color: {{VALUE}}',
				],
				'default' => '#bfbfbf',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .follow .description',
			]
		);

		$this->add_responsive_control(
			'description_margin',
			[
				'label' => __( 'Margin', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .follow .description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'show_follow',
							'operator' => '!=',
							'value' => '',
						],
					],
				],
			]
		);

		$this->add_responsive_control(
			'content_follow_padding',
			[
				'label' => __( 'Padding', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .follow a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'show_follow',
							'operator' => '!=',
							'value' => '',
						],
					],
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_slide',
			[
				'label' => __( 'Slide', 'ova-framework' ),
				'tab' => \Elementor\Controls_Manager::HEADING,
			]
		);

			$this->add_control(
				'show_nav',
				[
					'label' => __( 'Show Nav', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label' => __( 'Autoplay', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
				]
			);

			$this->add_control(
				'pause_on_hover',
				[
					'label' => __( 'Pause on Hover', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'autoplay' => 'yes',
					],
				]
			);

			$this->add_control(
				'autoplay_speed',
				[
					'label' => __( 'Autoplay Speed (ms)', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 3000,
					'condition' => [
						'autoplay' => 'yes',
					],
				]
			);

			$this->add_control(
				'loop',
				[
					'label' => __( 'Loop', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
				]
			);

			$this->add_control(
				'lazy_load',
				[
					'label' => __( 'Lazy Load', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
				]
			);
			$this->add_control(
				'transiton_animate',
				[
					'label' => __( 'Transition Animate', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'min' => 250,
					'default' => 500,
				]
			);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();
		$html = '';

		// Slide
		
		$instagram_slide = [
			'autoplayTimeout'    => absint( $settings['autoplay_speed'] ),
			'autoplay'           => ( 'yes' === $settings['autoplay'] ),
			'loop'               => ( 'yes' === $settings['loop'] ),
			'autoplayHoverPause' => ( 'yes' === $settings['pause_on_hover'] ),
			'lazyLoad'           => ( 'yes' === $settings['lazy_load'] ),
			'nav'                => ( 'yes' === $settings['show_nav'] ),
			'navText'            => [
				'<i class="fa fa-angle-left" aria-hidden="true"></i>',
				'<i class="fa fa-angle-right" aria-hidden="true"></i>'
			],
			'dots' => false,
			'smartSpeed' => 1000,
		];
		$this->add_render_attribute( 'slide', [
			'data-instagram_slide' => wp_json_encode( $instagram_slide),
		] );

		// get images Instagram
		$access_token = $settings['token'];
		$photo_count  = absint( $settings['number_photo'] );
		$json_link    = "https://api.instagram.com/v1/users/self/media/recent/?";
		$json_link    .= "access_token={$access_token}&count={$photo_count}";
		$json         = file_get_contents($json_link);
		$obj          = json_decode(preg_replace('/("\w+"):(\d+)/', '\\1:"\\2"', $json), true);
		// echo "<pre>";
		// var_dump ($obj); die;
		$user_name = $obj['data']['0']['user']['username'];


		$html .= '<div class="instagram">';
		$html .= $settings['show_follow'] == 'yes' ? '<div class="follow '.$settings['follow_version'].'">
			<a href="//instagram.com/'.$user_name.'">
				<i class="'.$settings['text_icon'].' icon_follow text-center"></i>
				<div class="title second_font text-center">'.$settings['title'].'</div>
				<div class="description text-center">'.$settings['description'].'</div>
			</a>
		</div>' : "";
		$html .= '<div class="slide owl-carousel owl-theme " '.$this->get_render_attribute_string( 'slide' ).'  >';
		
		foreach ($obj['data'] as $post){

			$pic_text          = $post['caption']['text'];
			$pic_link          = $post['link'];
			$pic_like_count    = $post['likes']['count'];
			$pic_comment_count = $post['comments']['count'];
			$pic_src           = str_replace('http://', "https://", $post['images']['standard_resolution']['url']);
			

			$html .= '<div class="item" >';
				
				$html .= '<div class="image" style="background-image: url('.$pic_src.'); height:'.$settings['height'].'px"  ></div>';
				$html .= '<div class="overlay" >';
					$html .= '<a href="'.$pic_link.'" target="_blank"><i class="linkToIns fab fa-instagram" ></i></a>';
				$html .= '</div>';
			$html .= '</div>';

		}

		$html .= '</div>';
		$html .= '</div>';
		
		echo $html;

	}
}
