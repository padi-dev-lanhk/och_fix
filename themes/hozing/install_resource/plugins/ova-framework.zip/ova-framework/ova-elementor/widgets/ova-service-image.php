<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_service_image extends Widget_Base {

	public function get_name() {
		return 'ova_service_image';
	}

	public function get_title() {
		return __( 'Service Image', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);
			$this->add_control(
				'active',
				[
					'label' => __( 'Active', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
				]
			);

			$this->add_control(
				'icon',
				[
					'label' => __( 'Class Icon', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'arrow_right', 'ova-framework' ),
				]
			);

			$this->add_control(
				'image_link',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
				]
			);

			$this->add_control(
				'link',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);


			$this->add_control(
				'title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'The Pool', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
				]
			);

			$this->add_control(
				'sub_title',
				[
					'label' => __( 'Sub Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'Pacilities', 'ova-framework' ),
					'placeholder' => __( 'Type your sub title here', 'ova-framework' ),
				]
			);

			$this->add_control(
				'descitpion',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => __( 'Discover Our Pool', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
				]
			);

		$this->end_controls_section();

		/*******************************************************************************
						TAB STYLE SERVICE IMAGE
		********************************************************************************/

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_service_ver_1',
			[
				'label' => __( 'Cover Image', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'cover_image_background_color_hover',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover:hover:before' => 'background-color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll cover image. ###############

		/*************  section controll icon. *******************/

		$this->start_controls_section(
			'section_icon_service',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_control(
				'color_icon_service',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .icon-service i:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon_service',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 150,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .icon-service i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_icon_service',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .icon-service' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_icon_service',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .icon-service' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll icon ###############################


		/*************  section controll sub title. *******************/

		$this->start_controls_section(
			'section_sub_title',
			[
				'label' => __( 'Sub Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'sub_title_typography',
					'selector' => '{{WRAPPER}} .ova-service-image .image-cover .content h4.sub-title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_sub_title',
				[
					'label' => __( 'Color Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .content h4.sub-title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_sub_title',
				[
					'label' => __( 'Margin Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .content h4.sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_sub_title',
				[
					'label' => __( 'Padding Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .content h4.sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll sub title ###############################


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .ova-service-image .image-cover .content h3.title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .content h3.title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .content h3.title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .content h3.title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography',
					'selector' => '{{WRAPPER}} .ova-service-image .image-cover .content p.desc',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .content p.desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .content p.desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-image .image-cover .content p.desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$icon 				= $settings['icon'];
		$image_link			= $settings['image_link']['url'];
		$link				= $settings['link']['url'];
		$target      		= $settings['link']['is_external'] ? ' target="_blank" ' : '';
		$nofollow   		= $settings['link']['nofollow'] ? ' rel="nofollow" ' : '';
		$title 				= $settings['title'];
		$sub_title 			= $settings['sub_title'];
		$descitpion 		= $settings['descitpion'];
		$active 			= $settings['active'] === 'yes' ? ' active ' : '';
		?>
			<div class="ova-service-image" style="background-image: url(<?php echo $image_link ?>);">
				<a href="<?php echo $link ?>" class="image-cover <?php echo $active ?>" <?php echo $target . $nofollow  ?> >
					<div class="icon-service">
						<i class="<?php echo $icon ?>"></i>
					</div>
					<div class="content">
						<h4 class="sub-title second_font"><?php echo $sub_title ?></h4>
						<h3 class="title second_font"><?php echo $title ?></h3>
						<p class="desc second_font"><?php echo $descitpion ?></p>
					</div>
				</a>	
			</div>
		<?php
	}
}
