<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_service_1 extends Widget_Base {

	public function get_name() {
		return 'ova_service';
	}

	public function get_title() {
		return __( 'Service', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}


	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			//Choose version service
			$this->add_control(
				'version_service',
				[
					'label' => __( 'Choose Version Blog', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'service_version_1',
					'options' => [
						'service_version_1' => __( 'Service Version 1', 'ova-framework' ),
						'service_version_2' => __( 'Service Version 2', 'ova-framework' ),
						'service_version_3' => __( 'Service Version 3', 'ova-framework' ),
						'service_version_4' => __( 'Service Version 4', 'ova-framework' ),
						'service_version_5' => __( 'Service Version 5', 'ova-framework' ),
					],
				]
			);

			/*************************************
					SERVICE VERSION 1
			**************************************/

			$this->add_control(
				'image_service_ver_1',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_service' => ['service_version_1'],
					],
				]
			);

			$this->add_control(
				'active_background_ver_1',
				[
					'label' => __( 'Active Background', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_1'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'active_background_mobile_ver_1',
				[
					'label' => __( 'Active Background Mobile', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_1'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'active_border_right_ver_1',
				[
					'label' => __( 'Active Border Right', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_1'],
					],
					'frontend_available' => true,
				]
			);


			$this->add_control(
				'hide_boder_right_1024_ver_1',
				[
					'label' => __( 'Hide Border Right 1024', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_1'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'visble_border_bottom_1024_ver_1',
				[
					'label' => __( 'Visble Border Bottom 1024', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_1'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'visble_border_bottom_768_ver_1',
				[
					'label' => __( 'Visble Border Bottom 768', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_1'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'link_service_ver_1',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
					'condition' => [
						'version_service' => ['service_version_1'],
					],
				]
			);

			$this->add_control(
				'title_service_ver_1',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'RESTAURANT', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_1'],
					],
				]
			);

			$this->add_control(
				'text_content_service_ver_1',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => __( 'Sed ut perspiciatis unde omnis iste natus error sit', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_1'],
					],
				]
			);

			$this->add_control(
				'text_class_icon_service_ver_1',
				[
					'label' => __( 'Class Icon', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'flaticon-mountain', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_1'],
					],
				]
			);
			#################### END SECTION controll service version 1  ###############################


			/***************************************************************************************************
										SECTION SERVICE VERSION 2
			****************************************************************************************************/

			$this->add_control(
				'image_service_ver_2',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_service' => ['service_version_2'],
					],
				]
			);

			$this->add_control(
				'active_background_ver_2',
				[
					'label' => __( 'Active Background', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_2'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'active_background_mobile_ver_2',
				[
					'label' => __( 'Active Background Mobile', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_2'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'link_service_ver_2',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
					'condition' => [
						'version_service' => ['service_version_2'],
					],
				]
			);

			$this->add_control(
				'title_service_ver_2',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'Tour with everyone', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_2'],
					],
				]
			);

			$this->add_control(
				'text_content_service_ver_2',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_2'],
					],
				]
			);

			$this->add_control(
				'text_class_icon_service_ver_2',
				[
					'label' => __( 'Class Icon', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'flaticon-mountain', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_2'],
					],
				]
			);
			#################### END SECTION controll service version 2  ###############################

		#################### END SECTION CONTROL CONTENT SERVICE 2    ###############################


		/***************************************************************************************************
										SECTION SERVICE VERSION 3
			****************************************************************************************************/

			$this->add_control(
				'image_service_ver_3',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_service' => ['service_version_3'],
					],
				]
			);

			$this->add_control(
				'active_background_ver_3',
				[
					'label' => __( 'Active Background', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_3'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'active_background_mobile_ver_3',
				[
					'label' => __( 'Active Background Mobile', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_3'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'link_service_ver_3',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
					'condition' => [
						'version_service' => ['service_version_3'],
					],
				]
			);

			$this->add_control(
				'title_service_ver_3',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'AIRPORT PICKUP', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_3'],
					],
				]
			);

			$this->add_control(
				'text_class_icon_service_ver_3',
				[
					'label' => __( 'Class Icon', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'flaticon-plane', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_3'],
					],
				]
			);
			#################### END SECTION controll service version 3  ###############################


			/*************************************
					SERVICE VERSION 4
			**************************************/

			$this->add_control(
				'service_border_hover_ver_4',
				[
					'label' => __( 'Is Image Border', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_4'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'active_background_ver_4',
				[
					'label' => __( 'Active Background', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_4'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'active_background_mobile_ver_4',
				[
					'label' => __( 'Active Background Mobile', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_4'],
					],
					'frontend_available' => true,
				]
			);


			$this->add_control(
				'min_height_ver_4',
				[
					'label' => __( 'Min Height Element', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( '270', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_4'],
					],
				]
			);

			$this->add_control(
				'image_service_ver_4',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_service' => ['service_version_4'],
					],
				]
			);



			$this->add_control(
				'link_service_ver_4',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
					'condition' => [
						'version_service' => ['service_version_4'],
					],
				]
			);

			$this->add_control(
				'title_service_ver_4',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'Touring', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_4'],
					],
				]
			);

			$this->add_control(
				'text_content_service_ver_4',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => __( 'Ut enim ad minim veniam, quis nostrud ', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_4'],
					],
				]
			);

			#################### END SECTION controll service version 4  ###############################

			/*************************************
					SERVICE VERSION 5
			**************************************/

			$this->add_control(
				'active_background_ver_5',
				[
					'label' => __( 'Active Background', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_5'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'active_background_mobile_ver_5',
				[
					'label' => __( 'Active Background Mobile', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_service' => ['service_version_5'],
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'link_service_ver_5',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
					'condition' => [
						'version_service' => ['service_version_5'],
					],
				]
			);

			$this->add_control(
				'title_service_ver_5',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'Belt Food', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_5'],
					],
				]
			);

			$this->add_control(
				'text_content_service_ver_5',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => __( 'Sed ut perspiciatis unde omnis iste natus error', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_5'],
					],
				]
			);

			$this->add_control(
				'text_class_icon_service_ver_5',
				[
					'label' => __( 'Class Icon', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'flaticon-food', 'ova-framework' ),
					'condition' => [
						'version_service' => ['service_version_5'],
					],
				]
			);
			#################### END SECTION controll service version 5  ###############################

		$this->end_controls_section();
		#################### END SECTION CONTROL CONTENT SERVICE    ###############################





		/*******************************************************************************
						TAB STYLE SERVICE VERSION 1
		********************************************************************************/

		/*************  section controll border *******************/

		$this->start_controls_section(
			'color_border_right_service_ver_1',
			[
				'label' => __( 'Color Border Right', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
						'version_service' => ['service_version_1'],
					],
			]
		);

			$this->add_control(
					'color_border_service_ver_1',
					[
						'label' => __( 'Color Border', 'ova-framework' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .ova-service.service_version_1' => 'border-color : {{VALUE}};',
						],
					]
				);

		$this->end_controls_section();

		###############  end section controll border ###############		

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_service_ver_1',
			[
				'label' => __( 'Cover Image', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
						'version_service' => ['service_version_1'],
					],
			]
		);		

			$this->add_control(
				'cover_image_background_color_hover_service_ver_1',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service .overlay:hover' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'cover_image_background_color_service_ver_1',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service .overlay' => 'background-color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll cover image. ###############

		/*************  section controll icon. *******************/

		$this->start_controls_section(
			'section_icon_service_ver_1',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_1'],
				],
			]
		);	

			$this->add_control(
				'color_icon_service_ver_1',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .icon-service i:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon_service_ver_1',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 150,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .icon-service i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_icon_service_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .icon-service' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_icon_service_ver_1',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .icon-service' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll icon ###############################

		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_service_ver_1',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_1'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_service_ver_1',
					'selector' => '{{WRAPPER}} .ova-service .content .service-title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_service_ver_1',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .service-title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_Title_service_ver_1',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .service-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_service_ver_1',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .service-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_service_ver_1',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_1'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography_service_ver_1',
					'selector' => '{{WRAPPER}} .ova-service .content .service-desc',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_service_ver_1',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .service-desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_service_ver_1',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .service-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_service_ver_1',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service .content .service-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################

		#################### END TAB STYLE SERVICE VERSION 1 ###############################


		/*******************************************************************************
						TAB STYLE SERVICE VERSION 2
		********************************************************************************/

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_service_ver_2',
			[
				'label' => __( 'Cover Image', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
						'version_service' => ['service_version_2'],
					],
			]
		);		

			$this->add_control(
				'cover_image_background_color_hover_service_ver_2',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .overlay:hover' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'cover_image_background_color_service_ver_2',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .overlay' => 'background-color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll cover image. ###############

		/*************  section controll icon. *******************/

		$this->start_controls_section(
			'section_icon_service_ver_2',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_2'],
				],
			]
		);	

			$this->add_control(
				'color_icon_service_ver_2',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .content .icon-service i:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon_service_ver_2',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 150,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .content .icon-service i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_icon_service_ver_2',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .content .icon-service' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_icon_service_ver_2',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .content .icon-service' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll icon ###############################

		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_service_ver_2',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_2'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_service_ver_2',
					'selector' => '{{WRAPPER}} .ova-service.service_version_2 .service-title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_service_ver_2',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .service-title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_Title_service_ver_2',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .service-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_service_ver_2',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .service-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_service_ver_2',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_2'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography_service_ver_2',
					'selector' => '{{WRAPPER}} .ova-service.service_version_2 .service-desc',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_service_ver_2',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .service-desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_service_ver_2',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .service-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_service_ver_2',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .service-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################

		#################### END TAB STYLE SERVICE VERSION 2 ###############################


		/*******************************************************************************
						TAB STYLE SERVICE VERSION 3
		********************************************************************************/

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_service_ver_3',
			[
				'label' => __( 'Cover Image', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
						'version_service' => ['service_version_3'],
					],
			]
		);		

			$this->add_control(
				'cover_image_background_color_hover_service_ver_3',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_3 .overlay:hover' => 'background-color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll cover image. ###############

		/*************  section controll icon. *******************/

		$this->start_controls_section(
			'section_icon_service_ver_3',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_3'],
				],
			]
		);	

			$this->add_control(
				'color_icon_service_ver_3',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_3 .icon-service i:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon_service_ver_3',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 150,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_3 .icon-service i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_icon_service_ver_3',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_3 .icon-service' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_icon_service_ver_3',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_3 .icon-service' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll icon ###############################

		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_service_ver_3',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_3'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_service_ver_3',
					'selector' => '{{WRAPPER}} .ova-service.service_version_3 .service-title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_service_ver_3',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_3 .service-title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_Title_service_ver_3',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_3 .service-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_service_ver_3',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_3 .service-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_service_ver_3',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_3'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography_service_ver_3',
					'selector' => '{{WRAPPER}} .ova-service.service_version_2 .service-desc',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_service_ver_3',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .service-desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_service_ver_3',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_2 .service-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_service_ver_3',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_3 .service-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################

		#################### END TAB STYLE SERVICE VERSION 3 ###############################


		/*******************************************************************************
						TAB STYLE SERVICE VERSION 4
		********************************************************************************/

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_service_ver_4',
			[
				'label' => __( 'Cover Image', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_4'],
				],
			]
		);		

			$this->add_control(
				'cover_image_background_color_hover_service_ver_4',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(185,162,113,0.9)',
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_4 .overlay:hover'  => 'background-color : {{VALUE}};',
						'{{WRAPPER}} .ova-service.service_version_4 .overlay.active-background' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'cover_image_background_color_service_ver_4',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_4 .overlay' => 'background-color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll cover image. ###############


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_service_ver_4',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_4'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_service_ver_4',
					'selector' => '{{WRAPPER}} .ova-service.service_version_4 .overlay .content h3.service-title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_service_ver_4',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_4 .overlay .content h3.service-title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_Title_service_ver_4',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_4 .overlay .content h3.service-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_service_ver_4',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_4 .overlay .content h3.service-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_service_ver_4',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_4'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography_service_ver_4',
					'selector' => '{{WRAPPER}} .ova-service.service_version_4 .overlay .content p.service-desc',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_service_ver_4',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_4 .overlay .content p.service-desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_service_ver_4',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_4 .overlay .content p.service-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_service_ver_4',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_4 .overlay .content p.service-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################

		#################### END TAB STYLE SERVICE VERSION 4 ############################## #


		/*******************************************************************************
						TAB STYLE SERVICE VERSION 5
		********************************************************************************/

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_service_ver_5',
			[
				'label' => __( 'Cover Image', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_5'],
				],
			]
		);		

			$this->add_control(
				'cover_image_background_color_hover_service_ver_5',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay:hover, {{WRAPPER}} .ova-service.service_version_5 .overlay.active-background ' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'cover_image_background_color_service_ver_5',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay' => 'background-color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll cover image. ###############


		/*************  section controll icon. *******************/

		$this->start_controls_section(
			'section_icon_service_ver_5',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_5'],
				],
			]
		);	

			$this->add_control(
				'color_icon_service_ver_5',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .icon-service i:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon_service_ver_5',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 150,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .icon-service i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_icon_service_ver_5',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .icon-service' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_icon_service_ver_5',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .icon-service' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll icon ###############################

		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_service_ver_5',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_5'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_service_ver_5',
					'selector' => '{{WRAPPER}} .ova-service.service_version_5 .overlay .content .service-title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_service_ver_5',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .service-title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_Title_service_ver_5',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .service-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_service_ver_5',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .service-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################

		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_service_ver_5',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_service' => ['service_version_5'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography_service_ver_5',
					'selector' => '{{WRAPPER}} .ova-service.service_version_5 .overlay .content .service-desc',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_service_ver_5',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .service-desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_service_ver_5',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .service-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_service_ver_5',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service.service_version_5 .overlay .content .service-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$version_service = $settings['version_service'];
		$class_icon = $url_image = $link_images = $target = $title = $desc = $class_border_image = $active_background = $min_height = $hide_991 = $hide_1024 = $active_background_mobile = $visble_border_bottom = $visble_border_bottom_1024 =  $visble_border_bottom_768 = $active_border_right = "";

		switch ($version_service) {
			case "service_version_1" : {
				$class_icon 						= $settings['text_class_icon_service_ver_1'];
				$url_image  						= $settings['image_service_ver_1']['url'];
				$link_images						= $settings['link_service_ver_1']['url'];
				$target      						= $settings['link_service_ver_1']['is_external'] ? ' target="_blank"' : '';
				$title       						= $settings['title_service_ver_1'];
				$desc      							= $settings['text_content_service_ver_1'];
				$active_background  				= $settings['active_background_ver_1'] === 'yes' ? ' active-background ' : '';
				$hide_1024							= $settings['hide_boder_right_1024_ver_1'] === 'yes' ? ' hide-1024 ' : '';
				$visble_border_bottom_1024				= $settings['visble_border_bottom_1024_ver_1'] === 'yes' ? ' border-bot-1024 ' : '';
				$visble_border_bottom_768				= $settings['visble_border_bottom_768_ver_1'] === 'yes' ? ' border-bot-768 ' : '';
				$active_background_mobile 			= $settings['active_background_mobile_ver_1'] === 'yes' ? ' active-background-mobile ' : '';
				$active_border_right                = $settings['active_border_right_ver_1'] === 'yes' ? 'border-right: 1px solid rgba(255,255,255,0.3)' : '';
				break;
			}

			case "service_version_2" : {
				$class_icon  				= $settings['text_class_icon_service_ver_2'];
				$url_image   				= $settings['image_service_ver_2']['url'];
				$link_images				= $settings['link_service_ver_2']['url'];
				$target     				= $settings['link_service_ver_2']['is_external'] ? ' target="_blank"' : '';
				$title      				= $settings['title_service_ver_2'];
				$desc       				= $settings['text_content_service_ver_2'];
				$active_background  		= $settings['active_background_ver_2'] === 'yes' ? ' active-background ' : '';
				$active_background_mobile  	= $settings['active_background_mobile_ver_2'] === 'yes' ? ' active-background-mobile ' : '';
				break;
			}

			case "service_version_3" : {
				$class_icon  				= $settings['text_class_icon_service_ver_3'];
				$url_image   				= $settings['image_service_ver_3']['url'];
				$link_images 				= $settings['link_service_ver_3']['url'];
				$target      				= $settings['link_service_ver_3']['is_external'] ? ' target="_blank"' : '';
				$title       				= $settings['title_service_ver_3'];
				$active_background  		= $settings['active_background_ver_3'] === 'yes' ? ' active-background ' : '';
				$active_background_mobile  	= $settings['active_background_mobile_ver_3'] === 'yes' ? ' active-background-mobile ' : '';
				break;
			}

			case "service_version_4" : {
				$url_image   				= $settings['image_service_ver_4']['url'];
				$link_images 				= $settings['link_service_ver_4']['url'];
				$target      				= $settings['link_service_ver_4']['is_external'] ? ' target="_blank"' : '';
				$title      				= $settings['title_service_ver_4'];
				$desc        				= $settings['text_content_service_ver_4'];
				$class_border_image			= $settings['service_border_hover_ver_4'] === 'yes' ? ' border-image ' : '';
				$active_background  		= $settings['active_background_ver_4'] === 'yes' ? ' active-background ' : '';
				$min_height  				= 'min-height:' . $settings['min_height_ver_4'] . 'px';
				$active_background_mobile  	= $settings['active_background_mobile_ver_4'] === 'yes' ? ' active-background-mobile ' : '';
				break;
			}

			case "service_version_5" : {
				$class_icon  				= $settings['text_class_icon_service_ver_5'];
				$link_images 				= $settings['link_service_ver_5']['url'];
				$target      				= $settings['link_service_ver_5']['is_external'] ? ' target="_blank"' : '';
				$title      				= $settings['title_service_ver_5'];
				$desc        				= $settings['text_content_service_ver_5'];
				$active_background 			= $settings['active_background_ver_5'] === 'yes' ? ' active-background ' : '';
				$active_background_mobile  	= $settings['active_background_mobile_ver_5'] === 'yes' ? ' active-background-mobile ' : '';
				break;
			}
		}

		?>
			<div class="ova-service <?php echo $version_service .$hide_1024 ?>" style="background-image: url(<?php echo $url_image ?>); <?php echo $min_height . $active_border_right?>">
				<a href="<?php echo esc_html( $link_images ); ?>" <?php echo esc_html( $target); ?> class="overlay <?php echo  $active_background .$class_border_image . $active_background_mobile .$visble_border_bottom_1024 . $visble_border_bottom_768 ?>">
					<div class="content">
						<div class="icon-service">
							<i class="<?php echo $class_icon ?>"></i>
						</div>
						<h3 class="service-title second_font"><?php echo $title; ?></h3>
						<?php if (!empty($desc)) : ?>
							<p class="service-desc"><?php echo $desc; ?></p>
						<?php endif ?>
					</div>
				</a>
			</div>

		<?php
	}
}
