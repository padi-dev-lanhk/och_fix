<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_about_coloumn extends Widget_Base {

	public function get_name() {
		return 'ova_about_column';
	}

	public function get_title() {
		return __( 'About Column', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		//Choose version service
			$this->add_control(
				'version_about',
				[
					'label' => __( 'Choose Version About', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'about_version_1',
					'options' => [
						'about_version_1' => __( 'About Version Two Column', 'ova-framework' ),
						'about_version_3' => __( 'About Version Three Column (Contact)', 'ova-framework' ),
						'about_version_2' => __( 'About Version Four Column', 'ova-framework' ),
						'about_version_4' => __( 'About Version Three Column (Image) Column', 'ova-framework' ),
					],
				]
			);

			/**********************************************************************************
									ABOUT COLUMN VERSION 1 TWO COLUMN
			**********************************************************************************/


			$this->add_control(
				'icon_ver_1',
				[
					'label' => __( 'icon', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'flaticon-dinner',
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);


			$this->add_control(
				'link_ver_1',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => false,
					],
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);

			$this->add_control(
				'title_ver_1',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'FREE CITY TOUR', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);
			

			$this->add_control(
				'description_ver_1',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 3,
					'default' => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);

			##################### END SECTION CONTENT ABOUT VERSION 1 TWO COLUMN ############################



			/**********************************************************************************
									ABOUT COLUMN VERSION 2 FOUR COLUMN
			**********************************************************************************/
			$this->add_control(
				'year_ver_2',
				[
					'label' => __( 'Year', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '1932', 'ova-framework' ),
					'placeholder' => __( 'Type year here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			$this->add_control(
				'title_ver_2',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'WELCOME TO HOZING', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			$this->add_control(
				'link_ver_2',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => false,
					],
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);
			

			$this->add_control(
				'description_ver_2',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 3,
					'default' => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			$this->add_control(
				'active_border_right_ver_2',
				[
					'label' => __( 'Active Border Right', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_about' => 'about_version_2',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'hide_boder_right_1024_ver_2',
				[
					'label' => __( 'Hide Border Right 1024', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_about' => 'about_version_2',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'hide_boder_right_768_ver_2',
				[
					'label' => __( 'Hide Border Right 768', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_about' => 'about_version_2',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'visble_border_bottom_1024_ver_2',
				[
					'label' => __( 'Visble Border Bottom 1024', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_about' => 'about_version_2',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'visble_border_bottom_768_ver_2',
				[
					'label' => __( 'Visble Border Bottom 768', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_about' => 'about_version_2',
					],
					'frontend_available' => true,
				]
			);


			##################### END SECTION CONTENT ABOUT VERSION 2 FOUR CLOUMN ############################

			/**********************************************************************************
									ABOUT COLUMN VERSION 3 THREE COLUMN
			**********************************************************************************/


			$this->add_control(
				'icon_ver_3',
				[
					'label' => __( 'icon', 'ova-framework' ),
					'type' => Controls_Manager::ICON,
					'default' => 'fa fa-address-card-o',
					'condition' => [
						'version_about' => 'about_version_3',
					],
				]
			);
			

			$this->add_control(
				'description_ver_3',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::WYSIWYG,
					'rows' => 2,
					'default' => __( '<p>Email: hozingoffical@gmail.com</p><p>www:hozingluxury.com</p>', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_3',
					],
				]
			);

			########### END SECTION CONTENT ABOUT VERSION 3 THREE CLOUMN (CONTACT) #########

			/**********************************************************************************
										ABOUT COLUMN VERSION 4 THREE COLUMN (IMAGE)
			**********************************************************************************/

			$this->add_control(
				'image_about_ver_4',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_about' => 'about_version_4',
					],
				]
			);

			$this->add_control(
				'title_ver_4',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'FREE CITY TOUR', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_4',
					],
				]
			);

			$this->add_control(
				'link_ver_4',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => false,
					],
					'condition' => [
						'version_about' => 'about_version_4',
					],
				]
			);

			$this->add_control(
				'description_ver_4',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 3,
					'default' => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_4',
					],
				]
			);

			########### END SECTION CONTENT ABOUT VERSION 4 THREE CLOUMN (IMAGE) #########


		$this->end_controls_section();

		


		/*******************************************************************************
						TAB STYLE ABOUT TWO COLUMN
		********************************************************************************/

		/*************  section controll icon. *******************/

		$this->start_controls_section(
			'section_icon_about__ver_1',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => ['about_version_1'],
				],
			]
		);	

			$this->add_control(
				'color_icon_about_ver_1',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .icon i:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon_about_ver_1',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 150,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .icon i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_icon_about_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .icon i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_icon_about_ver_1',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .icon i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll icon ###############################	


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_about_ver_1',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_about_ver_1',
					'selector' => '{{WRAPPER}} .ova-about-column .wp-about-column .content .title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_about_ver_1',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .content .title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_title_about_ver_1',
				[
					'label' => __( 'Color Hover Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .content .title a:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_Title_about_ver_1',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_about_ver_1',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .content .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_about_ver_1',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => ['about_version_1'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography_about_ver_1',
					'selector' => '{{WRAPPER}} .ova-about-column .wp-about-column .content .desc',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_about_ver_1',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .content .desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_about_ver_1',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .content .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_about_ver_1',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column .content .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################

		/*******************************************************************************
						TAB STYLE ABOUT FOUR COLUMN
		********************************************************************************/


		/*************  section controll year. *******************/

		$this->start_controls_section(
			'section_year_about_ver_2',
			[
				'label' => __( 'Year', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_2',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'year_typography_about_ver_2',
					'selector' => '{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .year h4',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_year_about_ver_2',
				[
					'label' => __( 'Color Year', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .year h4' => 'color : {{VALUE}};',
					],
				]
			);



			$this->add_responsive_control(
				'margin_year_about_ver_2',
				[
					'label' => __( 'Margin Year', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .year h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_year_about_ver_2',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .year h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll year ###############################


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_about_ver_2',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_2',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_about_ver_2',
					'selector' => '{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .content .title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_about_ver_2',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .content .title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_title_about_ver_2',
				[
					'label' => __( 'Color Hover Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .content .title a:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_Title_about_ver_2',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_about_ver_2',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .content .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_about_ver_2',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => ['about_version_2'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography_about_ver_2',
					'selector' => '{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .content .desc',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_about_ver_2',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .content .desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_about_ver_2',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .content .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_about_ver_2',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_2 .content .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll description ###############################

		/*******************************************************************************
						TAB STYLE ABOUT THREE COLUMN CONTACT
		********************************************************************************/

		/*************  section controll icon. *******************/

		$this->start_controls_section(
			'section_icon_about_ver_3',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => ['about_version_3'],
				],
			]
		);	

			$this->add_control(
				'color_icon_about_ver_3',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_3 .icon i:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_icon_about_ver_3',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 150,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_3 .icon i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_icon_about_ver_3',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_3 .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_icon_about_ver_3',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_3 .icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll icon ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_about_ver_3',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => ['about_version_3'],
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography_about_ver_3',
					'selector' => '{{WRAPPER}} .ova-about-column .wp-about-column.about_version_3 .content .desc p',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_about_ver_3',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_3 .content .desc p' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_about_ver_3',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_3 .content .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_about_ver_3',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-column .wp-about-column.about_version_3 .content .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll description ###############################


	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		$version_about = $settings['version_about'];
		$icon = $title = $year = $desc = $link = $target = $about_center = $padding_left_content =  $active_border_right = $hide_border_right_1024 = $hide_border_right_768 = $visble_border_bottom_1024 = $visble_border_bottom_768 = "";
		switch ($version_about) {
			case "about_version_1" : {
				$icon 		= $settings['icon_ver_1'];
				$title 		= $settings['title_ver_1'];
				$desc 		= $settings['description_ver_1'];
				$link 		= $settings['link_ver_1']['url'];
				$target 	= $settings['link_ver_1']['is_external'] ? ' target="_blank"' : '';
				break;
			}
			case "about_version_2" : {
				$year 		= $settings['year_ver_2'];
				$title 		= $settings['title_ver_2'];
				$desc 		= $settings['description_ver_2'];
				$link 		= $settings['link_ver_2']['url'];
				$target 	= $settings['link_ver_2']['is_external'] ? ' target="_blank"' : '';
				$active_border_right                = $settings['active_border_right_ver_2'] === 'yes' ? ' border-right: 1px solid #e8e8e8 ' : '';
				$hide_border_right_1024 		 = $settings['hide_boder_right_1024_ver_2'] === 'yes' ? ' hide-border-right-1024 ' : ''; 
				$hide_border_right_768 		 = $settings['hide_boder_right_768_ver_2'] === 'yes' ? ' hide-border-right-768 ' : ''; 
				$visble_border_bottom_1024 		 = $settings['visble_border_bottom_1024_ver_2'] === 'yes' ? ' visble-bot-1024 ' : ''; 
				$visble_border_bottom_768 		 = $settings['visble_border_bottom_768_ver_2'] === 'yes' ? ' visble-bot-768 ' : ''; 

				break;
			}
			case "about_version_3" : {
				$icon 							= $settings['icon_ver_3']; 
				$desc 							= $settings['description_ver_3'];
				// $padding_left_content 			= $settings['padding_left_content_ver_3']; 
				// $about_center 					= $settings['text_center_ver_3'] === 'yes' ? ' text-align: center; ' : ' padding-left: '.$padding_left_content.'px; ';
				break;
			}
			case "about_version_4" : {
				$image 		= $settings['image_about_ver_4']['url'];
				$title 		= $settings['title_ver_4'];
				$desc 		= $settings['description_ver_4'];
				$link 		= $settings['link_ver_4']['url'];
				$target 	= $settings['link_ver_4']['is_external'] ? ' target="_blank"' : '';
				break;
			}
		}

	?>
		<div class="ova-about-column">
			<div class="wp-about-column <?php echo $version_about . $hide_border_right_1024 . $hide_border_right_768 . $visble_border_bottom_1024 . $visble_border_bottom_768  ?>" style="<?php echo $active_border_right ?>">
				<?php if (!empty($icon)) : ?>
					<div class="icon">
						<i class="<?php echo $icon ?>"></i>
					</div>
				<?php endif ?>
				<?php if (!empty($year)) : ?>
					<div class="year">
						<h4 class="second_font"><?php echo $year ?></h4>
					</div>
				<?php endif ?>
				<?php if (!empty ($image)) : ?>
					<div class="image">
						<a href="<?php echo $link ?>" <?php echo $target ?>>
							<img src="<?php echo $image  ?>" alt="">
						</a>
					</div>
				<?php endif ?>
				<div class="content ">
					<?php if (!empty($title)) : ?>
						<h3 class="title second_font"><a href="<?php echo $link ?>" <?php echo $target ?>><?php echo $title ?></a></h3>
					<?php endif ?>
					<?php if($version_about !== 'about_version_3') : ?>
						<p class="desc"><?php echo $desc ?></p>
					<?php else : ?>
						<div class="desc"><?php echo $desc ?></div>
					<?php endif ?>
				</div>
			</div>
		</div>
 		
	<?php
	}
}
