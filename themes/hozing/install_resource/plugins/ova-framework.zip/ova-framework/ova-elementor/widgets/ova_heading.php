<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_heading extends Widget_Base {

	public function get_name() {
		return 'ova_heading';
	}

	public function get_title() {
		return __( 'Ova Heading', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-heading';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}


	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);
			$this->add_control(
				'heading_version',
				[
					'label' => __( 'Version', 'ova-framework' ),
					'type' => Controls_Manager::HEADING,
				]
			);
			$this->add_control(
				'heading',
				[
					'label' => _x( 'Heading', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'version_1',
					'separator' => 'after',
					'options' => [
						'version_1' => _x( 'Version 1', 'ova-framework' ),
						'version_2' => _x( 'Version 2', 'ova-framework' ),
						'version_3' => _x( 'Version 3', 'ova-framework' ),
						'version_4' => _x( 'Version 4', 'ova-framework' ),
						'version_5' => _x( 'Version 5', 'ova-framework' ),
						'version_6' => _x( 'Version 6', 'ova-framework' ),
						'version_7' => _x( 'Version 7', 'ova-framework' ),
						'version_8' => _x( 'Version 8', 'ova-framework' ),
						'version_9' => _x( 'Version 9', 'ova-framework' ),
						'version_10' => _x( 'Version 10', 'ova-framework' ),
						'version_cus' => _x( 'Version Customize', 'ova-framework' ),
					],
				]
			);

			$this->add_responsive_control(
				'align',
				[
					'label' => __( 'Alignment', 'ova-framework' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left'    => [
							'title' => __( 'Left', 'ova-framework' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'ova-framework' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'ova-framework' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'toggle' => false,
					'selectors' => [
						'{{WRAPPER}} .ova_heading' => 'text-align: {{VALUE}};',
					],

				]
			);

			$this->add_control(
				'heading_title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => Controls_Manager::HEADING,
				]
			);

			$this->add_control(
				'text_title',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Room & Suites', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typo',
					'selector'	=> '{{WRAPPER}} .ova_heading .text_title'
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_heading .text_title' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'background_color_title',
				[
					'label' => __( 'Background', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_heading .title .text_title' => 'background-color: {{VALUE}};',
					],
					'description' => 'Please set background same background color column'
				]
			);

			$this->add_responsive_control(
				'margin_title',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_heading .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_heading .title .text_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'heading_sub_title',
				[
					'label' => __( 'Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_sub_title',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Discover', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'sub_title_typo',
					'selector'	=> '{{WRAPPER}} .ova_heading .sub_title'
				]
			);

			$this->add_control(
				'color_sub_title',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_heading .sub_title' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_sub_title',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_heading .sub_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'heading_image',
				[
					'label' => __( 'Images', 'ova-framework' ),
					'type' => Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'images',
				[
					'type' => Controls_Manager::MEDIA,
					'dynamic' => [
						'active' => true,
					],
					'default' => [
						'url' => OVA_PLUGIN_URI.'/assets/img/line_heading.png',
					],
				]
			);

			$this->add_control(
				'heading_description',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_des',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'DISCOVER NEWS UPDATE', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'des_typo',
					'label' => __( 'Typo Description', 'ova-framework' ),
					'selector' => '{{WRAPPER}} .ova_heading .description',
				]
			);

			$this->add_control(
				'color_des',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_heading .description' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'heading_icon',
				[
					'label' => __( 'Icon', 'ova-framework' ),
					'type' => Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'icon_top',
				[
					'label' => __( 'Icons Top', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::ICON,
					'default' => 'fa fa-home',
				]
			);

			$this->add_control(
				'size_icon_top',
				[
					'label' => __( 'Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_heading .icon_top i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'color_icon_top',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_heading .icon_top i' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'icon_bottom',
				[
					'label' => __( 'Icons Bottom', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::ICON,
					'default' => '',
				]
			);

			$this->add_control(
				'size_icon_bottom',
				[
					'label' => __( 'Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_heading .icon_bottom i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'color_icon_bottom',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_heading .icon_bottom i' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'heading_line',
				[
					'label' => __( 'Line', 'ova-framework' ),
					'type' => Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'show_line_vertical',
				[
					'label' => __( 'Line Vertical', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'ova-framework' ),
					'label_off' => __( 'Hide', 'ova-framework' ),
					'selectors' => [
						'{{WRAPPER}} .ova_heading .line_bottom:after' => 'display: block',
					],
					'default' => 'yes',
				]
			);

			$this->add_control(
				'color_line_vertical',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_heading .line_bottom:after' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'show_line_horizontal_middle',
				[
					'label' => __( 'Line Horizontal Middle', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'ova-framework' ),
					'label_off' => __( 'Hide', 'ova-framework' ),
					'selectors' => [
						'{{WRAPPER}} .ova_heading .title .line_left:after' => 'display: block',
						'{{WRAPPER}} .ova_heading .title .line_left:before' => 'display: block',
						'{{WRAPPER}} .ova_heading .title .line_right:after' => 'display: block',
						'{{WRAPPER}} .ova_heading .title .line_right:before' => 'display: block',
					],
					'default' => 'yes',
				]
			);
			$this->add_control(
				'color_line_horizontal_middle',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_heading .title .line_left:after' => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ova_heading .title .line_left:before' => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ova_heading .title .line_right:after' => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ova_heading .title .line_right:before' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'show_line_horizontal_bottom',
				[
					'label' => __( 'Line Horizontal Bottom', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'ova-framework' ),
					'label_off' => __( 'Hide', 'ova-framework' ),
					'selectors' => [
						'{{WRAPPER}} .ova_heading .line_bottom:before' => 'display: block',
					],
					'default' => 'yes',
				]
			);

			$this->add_control(
				'color_line_horizontal_bottom',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_heading .line_bottom:before' => 'background-color: {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();
		$images = $settings['images']['url'] != '' ? $settings['images']['url'] : '';

		?>
		
		<div class="ova_heading <?php echo esc_attr( $settings['heading'] ) ; ?> ">
			<div class="icon_top"><i class="<?php echo esc_attr( $settings['icon_top'] ); ?>"></i></div>
			<div class="sub_title second_font"><?php echo esc_attr( $settings['text_sub_title'] ); ?></div>
			<div class="title second_font">
				<span class="line_left"></span>
				<div class="text_title"><?php echo $settings['text_title']; ?></div>
				<span class="line_right"></span>
			</div>
			<div class="line_bottom"></div>
			<div class="description second_font"><?php echo esc_attr( $settings['text_des'] ); ?></div>
			<?php if (!empty($images)) : ?>
				<img class="images" src="<?php echo esc_url( $images ); ?>" alt="" />
			<?php endif; ?>
			<div class="icon_bottom"><i class="<?php echo esc_attr( $settings['icon_bottom'] ); ?>"></i></div>
		</div>

		<?php 
	}
}
