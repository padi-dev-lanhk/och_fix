<?php
namespace ova_framework\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_offers_5 extends Widget_Base {

	public function get_name() {
		return 'ova_offers_5';
	}

	public function get_title() {
		return __( 'Offers 5', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-product-upsell ';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_offers',
			[
				'label' => __( 'Images', 'ova-framework' ),
			]
		);
			$this->add_control(
				'images',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				]
			);


		$this->end_controls_section();

		/**** Content ****/
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);
			$this->add_control(
				'position',
				[
					'label' => __( 'Position', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						'right'  => __( 'Right', 'ova-framework' ),
						'' => __( 'Left', 'ova-framework' ),
					],
				]
			);
			$this->add_control(
				'price',
				[
					'label' => __( 'Price', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_price',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( '$350', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'price_typography',
					'selector' => '{{WRAPPER}} .offers_5 .price .number_price',
				]
			);

			$this->add_control(
				'margin_price',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .offers_5 .price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'price_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_5 .price .number_price' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_title',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'WEEKEN SPA OFFER', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .offers_5 .title ',
				]
			);

			$this->add_control(
				'margin_title',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .offers_5 .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_5 .title ' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'description',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_description',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit,  ametconsectetur, adipis civelit sed quia non qui dolorem ipsum quia dolor sit amet ', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'selector' => '{{WRAPPER}} .offers_5 .description ',
				]
			);

			$this->add_control(
				'margin_description',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .offers_5 .description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'description_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_5 .description ' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'button',
				[
					'label' => __( 'Button', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_button',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'BOOK NOW' ),
				]
			);

			$this->add_control(
				'link_button',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => false,
					],
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'selector' => '{{WRAPPER}} .offers_5 .button a',
				]
			);

			$this->add_control(
				'margin_button',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .offers_5 .button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'padding_button',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .offers_5 .button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'border_style',
				[
					'label' => __( 'Border Style', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'solid',
					'options' => [
						'solid'  => __( 'Solid', 'ova-framework' ),
						'dashed' => __( 'Dashed', 'ova-framework' ),
						'dotted' => __( 'Dotted', 'ova-framework' ),
						'double' => __( 'Double', 'ova-framework' ),
						'none' => __( 'None', 'ova-framework' ),
					],
					'selectors' => [
						'{{WRAPPER}} .offers_5 .button a' => 'border-style: {{VALUE}};',
					],
				]
			);

			$this->start_controls_tabs( 'tabs_button_style' );

			$this->start_controls_tab(
				'tab_button_normal',
				[
					'label' => __( 'Normal', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .offers_5 .button a' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_5 .button a' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'border_color',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_5 .button a' => 'border-color: {{VALUE}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name' => 'border_style',
								'operator' => '!=',
								'value' => 'none',
							],
						],
					],
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_button_hover',
				[
					'label' => __( 'Hover', 'ova-framework' ),
				]
			);

			$this->add_control(
				'hover_color',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_5 .button a:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_hover_color',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_5 .button a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_hover_border_color',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'conditions' => [
						'terms' => [
							[
								'name' => 'border_style',
								'operator' => '!=',
								'value' => 'none',
							],
						],
					],
					'selectors' => [
						'{{WRAPPER}} .offers_5 .button a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'hover_animation',
				[
					'label' => __( 'Hover Animation', 'ova-framework' ),
					'type' => Controls_Manager::HOVER_ANIMATION,
				]
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();
		$this->end_controls_section();

		/**** Discount ****/
		$this->start_controls_section(
			'section_discount',
			[
				'label' => __( 'Discount', 'ova-framework' ),
			]
		);
			$this->add_control(
				'text_discount',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( '-50%', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'discount_typography',
					'selector' => '{{WRAPPER}} .offers_5 .discount ',
				]
			);

			$this->add_control(
				'discount_color',
				[
					'label' => __( 'Background', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_5 .discount ' => 'background: {{VALUE}}',
					],
				]
			);
		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings();
		$images = $settings['images']['url'] != '' ? $settings['images']['url'] : '';

		$link_button = $settings['link_button']['url'] ? $settings['link_button']['url'] : '';
		$target = $settings['link_button']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link_button']['nofollow'] ? ' rel="nofollow"' : '';
		?>
		<div class="offers_5 <?php echo $settings['position']; ?>">
			<img src="<?php echo esc_url($images); ?>" alt="">
			<div class="overlay_content"></div>
			<div class="content">
				<div class="price">
					<span class="number_price second_font"><?php echo $settings['text_price']; ?></span>
					<span class="slash"></span>
					<span class="text_price">Night</span>
				</div>
				<div class="title second_font"><?php echo $settings['text_title']; ?></div>
				<div class="description"><?php echo $settings['text_description']; ?></div>
				<div class="button">
					<a class="text_button <?php echo 'elementor-animation-'.esc_html( $settings['hover_animation'] ); ?>" href="<?php echo esc_html( $link_button ); ?>" <?php echo esc_html( $target); echo esc_html( $nofollow); ?> ><?php echo $settings['text_button']; ?></a>
				</div>
			</div>
			<div class="discount second_font"><?php echo $settings['text_discount']; ?></div>
		</div>
		<?php
	}
}