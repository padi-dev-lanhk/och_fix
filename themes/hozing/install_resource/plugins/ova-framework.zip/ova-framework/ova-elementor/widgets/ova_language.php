<?php
namespace ova_framework\Widgets;
use Elementor;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class ova_language extends Widget_Base {

	public function get_name() {
		return 'ova_language';
	}

	public function get_title() {
		return __( 'Choice Language', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-post-list';
	}

	public function get_categories() {
		return [ 'hf' ];
	}

	public function get_keywords() {
		return [ 'image', 'photo', 'visual' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'choice_language',
			[
				'label' => __( 'Language', 'ova-framework' ),
			]
		);

			$this->add_control(
				'color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_language .select2-selection__rendered' => 'color: {{VALUE}}',
						'{{WRAPPER}} .ova_language .select2-selection__arrow' => 'color: {{VALUE}}',
						
					],
				]
			);

			$this->add_control(
				'size',
				[
					'label' => __( 'Size', 'plugin-domain' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 30,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 14,
					],
					'selectors' => [
						'{{WRAPPER}} .select2-selection__rendered' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'plugin-domain' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'default' => 'center',
					'toggle' => true,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'plugin-domain' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'plugin-domain' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'plugin-domain' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_language' => 'text-align: {{VALUE}}',
					],
				]
			);
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();
		$html = '';
		
		$html .= '<div class="ova_language">';
			$html .= '<select class="form-control" >';
				$html .= '<option value="English" disabled selected>Language</option>';
				$html .= '<option value="English">English</option>';
				$html .= '<option value="German">German</option>';
				$html .= '<option value="Chinese">Chinese</option>';
				$html .= '<option value="Russian">Russian</option>';
			$html .= '</select>';
		$html .= '</div>';
		echo $html;
	}	
}

