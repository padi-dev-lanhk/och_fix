<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_blog_half_layout extends Widget_Base {

	public function get_name() {
		return 'ova_blog_half_layout';
	}

	public function get_title() {
		return __( 'Blog Half Layout', 'ova-framework' );
	}


	public function get_icon() {
		return 'fa fa-columns';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		$args = array(
		  'orderby' => 'name',
		  'order' => 'ASC'
		  );

		$categories=get_categories($args);
		$cate_array = array();
		$arrayCateAll = array( 'all' => 'All categories ' );
		if ($categories) {
			foreach ( $categories as $cate ) {
				$cate_array[$cate->cat_name] = $cate->slug;
			}
		} else {
			$cate_array["No content Category found"] = 0;
		}


		/*****************************************************************
						START BLOG SLIDER VERSION 1
			******************************************************************/
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			$this->add_control(
				'category',
				[
					'label' => __( 'Category', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'all',
					'options' => array_merge($arrayCateAll,$cate_array),
				]
			);

			$this->add_control(
				'total_count',
				[
					'label' => __( 'Total Post', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 3,
					'min' => 1,
				]
			);

			$this->add_control(
				'show_title',
				[
					'label' => __( 'Show Title', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_date',
				[
					'label' => __( 'Show Date', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_excerpt',
				[
					'label' => __( 'Show Excerpt', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

		$this->end_controls_section();
		//END SECTION CONTENT

		/*******************************************************************************
						TAB STYLE
		********************************************************************************/

		/*************  section controll date odd *******************/

		$this->start_controls_section(
			'date_odd',
			[
				'label' => __( 'Date Odd', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'font_size_text_date_odd',
				[
					'label' => __( 'Font Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 80,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-half-layout-element .post-item.odd .post-meta .post-date .day' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'color_text_date_odd',
				[
					'label' => __( 'Color Text', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0, 0, 0, 0.3)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-half-layout-element .post-item.odd .post-meta .post-date .day' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_date_odd',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#f3f3f3',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-half-layout-element .post-item.odd .post-meta .post-date' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'width_height_date',
				[
					'label' => __( 'Width Height', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 10,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-half-layout-element .post-item .post-meta .post-date' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll date odd ###############


		/*************  section controll date odd *******************/

		$this->start_controls_section(
			'date_even',
			[
				'label' => __( 'Date Even', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'font_size_text_date_even_day',
				[
					'label' => __( 'Font Size Day', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 80,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-half-layout-element .post-item.even .post-meta .post-date .day' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'color_text_date_even_day',
				[
					'label' => __( 'Color Text Day', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-half-layout-element .post-item.even .post-meta .post-date .day' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'font_size_text_date_even_month',
				[
					'label' => __( 'Font Size Month', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 80,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-half-layout-element .post-item.even .post-meta .post-date .month' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'color_text_date_even_month',
				[
					'label' => __( 'Color Text Month', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-half-layout-element .post-item.even .post-meta .post-date .month' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_date_even',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-half-layout-element .post-item.even .post-meta .post-date' => 'background-color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll date odd ###############


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova-blog-half-layout-element .post-item .content .post-title h2 a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-half-layout-element .post-item .content .post-title h2 a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-half-layout-element .post-item .content .post-title h2 a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-half-layout-element .post-item .content .post-title h2 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-half-layout-element .post-item .content .post-title h2 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll title. ###############


		/*************  section controll excerpt. *******************/

		$this->start_controls_section(
			'section_excerpt_style',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typography',
				'selector' => '{{WRAPPER}} .ova-blog-half-layout-element .post-item .content .post-excerpt p',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'excerpt_color',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-half-layout-element .post-item .content .post-excerpt p' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'excerpt_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-half-layout-element .post-item .content .post-excerpt p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-half-layout-element .post-item .content .post-excerpt p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll excerpt. ###############
		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		$category 		= $settings['category'];
		$total_count 	= $settings['total_count'];
		$show_title 	= $settings['show_title'];
		$show_date 		= $settings['show_date'];
		$show_excerpt 	= $settings['show_excerpt'];

		$args =array();
		if ($category == 'all') {
			$args=array('post_type' => 'post', 'posts_per_page' => $total_count);
		} else {
			$args=array('post_type' => 'post', 'category_name'=>$category,'posts_per_page' => $total_count);
		}
		$blog = new \WP_Query($args);

		
		?>
		
			<div class="ova-blog-half-layout-element">
				<?php
					if($blog->have_posts()) : while($blog->have_posts()) : $blog->the_post();
						$thumbnail_url = wp_get_attachment_image_url(get_post_thumbnail_id() , 'full' );
				?>
						<div class="post-item">
							<div class="post-meta hide-min-576">
								<div class="post-date">
									<span class="day second_font"><?php echo get_the_date( 'd' ); ?></span>
									<span class="month second_font"><?php echo get_the_time('F') ?></span>
								</div>
							</div>
							<div class="content">
								<?php  if ($show_title) : ?>
									<div class="post-title">
										<h2><a class="second_font" href="<?php the_permalink() ?>"><?php echo hozing_custom_text(get_the_title(), 4) ?></a></h2>
									</div>
								<?php endif ?>
									<div class="post-meta-mobile hide-max-576">
										<div class="post-date">
											<span class="date"><?php the_time( get_option( 'date_format' ));?></span>
										</div>
									</div>
								<?php  if ($show_excerpt) : ?>
									<div class="post-excerpt">
										<p><?php echo hozing_custom_text(get_the_excerpt(), 12) ?></p>
									</div>
								<?php endif ?>
							</div>
						</div>
				<?php
					endwhile; endif; wp_reset_postdata();
				?>
			</div>
				<!-- end ova-blog-half-layout-element -->
		<?php
	}
}
