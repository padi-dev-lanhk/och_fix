<?php
namespace ova_framework\Widgets;
use Elementor;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\REPEATER;



if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class ova_info_footer extends Widget_Base {

	public function get_name() {
		return 'ova_info_footer';
	}

	public function get_title() {
		return __( 'Info Footer', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-info';
	}

	public function get_categories() {
		return [ 'hf' ];
	}

	public function get_keywords() {
		return [ 'footer', 'photo', 'info' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
			]
		);

		$this->add_control(
			'title_version',
			[
				'label' => _x( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'version_1',
				'options' => [
					'version_1' => _x( 'Version 1', 'ova-framework' ),
					'version_2' => _x( 'Version 2', 'ova-framework' ),
					'version_3' => _x( 'Version 3', 'ova-framework' ),
					'version_cus' => _x( 'Customize', 'ova-framework' ),
				],
			]
		);

		$this->add_control(
			'text_title',
			[
				'label' => __( 'Text', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Location', 'ova-framework' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typo_title',
				'selector' => '{{WRAPPER}} .ova_info_footer .title',
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_info_footer .title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'margin_title',
			[
				'label' => __( 'Margin Title', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_info_footer .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'after',
			]
		);

		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_info',
			[
				'label' => __( 'Info', 'ova-framework' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'text_info',
			[
				'label' => __( 'Text', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => __( 'Info', 'ova-framework' ),
			]
		);

		$this->add_control(
			'list_info',
			[
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'text_info' => 'Info 1',
					],
					[
						'text_info' => 'Info 2',
					],
					[
						'text_info' => 'Info 3',
					],
				],
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'ova-framework' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'ova-framework' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ova-framework' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ova-framework' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'toggle' => true,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typo_info',
				'selector' => '{{WRAPPER}} .ova_info_footer .info',
			]
		);

		$this->add_control(
			'color_info',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_info_footer .info' => 'color: {{VALUE}}',
				],
				'separator' => 'after',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();
		$style_align = !(empty($settings['align'])) ? " text-align: " . $settings['align'] : '';

		?>
		
		<div class="ova_info_footer <?php echo $settings['title_version']; ?>" style="<?php echo $style_align ?>">
			<div class="wrap_title">
				<div class="title second_font"><?php echo $settings['text_title']; ?></div>
			</div>
			<div class="list_info">
				<?php foreach ( $settings['list_info'] as $index => $item ) { ?>
					<div class="info"><?php echo $item['text_info']; ?></div>
				<?php } ?>
			</div>
		</div>
		<?php
	}

	
}

