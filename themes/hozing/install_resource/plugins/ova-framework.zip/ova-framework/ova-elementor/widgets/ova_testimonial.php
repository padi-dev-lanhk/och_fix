<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class ova_testimonial extends Widget_Base {

	public function get_name() {
		return 'ova_testimonial';
	}

	public function get_title() {
		return __( 'Testimonial', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-testimonial';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}


	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_version_testimonial',
			[
				'label' => __( 'Version Testimonial', 'ova-framework' ),
			]
		);
			//Choose version service
			$this->add_control(
				'version_testimonial',
				[
					'label' => __( 'Choose Version Testimonial', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'testimonial_version_1',
					'options' => [
						'testimonial_version_1' => __( 'Testimonial Version 1', 'ova-framework' ),
						'testimonial_version_2' => __( 'Testimonial Version 2', 'ova-framework' ),
					],
				]
			);

		$this->end_controls_section();

		############# END SECTION CHOOSE VERSION

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			$repeater_ver_1 = new \Elementor\Repeater();

				$repeater_ver_1->add_control(
					'author',
					[
						'label' => __( 'Author ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => __( 'Adam Levine', 'ova-framework' ),
					]
				);

				$repeater_ver_1->add_control(
					'title',
					[
						'label' => __( 'Title ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => __( 'Testimonial', 'ova-framework' ),
						'row' => 2,
					]
				);

				$repeater_ver_1->add_control(
					'content',
					[
						'label' => __( 'Title ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::WYSIWYG,
						'default' => __( '<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>', 'ova-framework' ),
						'row' => 2,
					]
				);

				$repeater_ver_1->add_control(
					'icon',
					[
						'label' => __( 'Icon ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => __( 'icon_quotations_alt2', 'ova-framework' ),
						'placeholder' => __( 'Class Font Elegant', 'ova-framework' ),
						'row' => 2,
					]
				);

				$repeater_ver_1->add_control(
					'number_star',
					[
						'label' => __( 'Number Star ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::SELECT,
						'default' => __( '5', 'ova-framework' ),
						'placeholder' => __( 'Class Font Elegant', 'ova-framework' ),
						'options' => [
							5 => 5,
							4 => 4,
							3 => 3,
							2 => 2,
							1 => 1
						],
					]
				);

				$this->add_control(
					'tabs_testimonial_ver_1',
					[
						'label' => __( 'Items Testimonial', 'ova-framework' ),
						'type' => Controls_Manager::REPEATER,
						'fields' => $repeater_ver_1->get_controls(),
						'title_field' => '{{{ title }}}',
						'condition' => [
							'version_testimonial' => 'testimonial_version_1',
						],
					]
				);


				$repeater_ver_2 = new \Elementor\Repeater();

				$repeater_ver_2->add_control(
					'author',
					[
						'label' => __( 'Author ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => __( 'Adam Levine', 'ova-framework' ),
					]
				);

				$repeater_ver_2->add_control(
					'title',
					[
						'label' => __( 'Title ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => __( 'Testimonial', 'ova-framework' ),
						'row' => 2,
					]
				);

				$repeater_ver_2->add_control(
					'content',
					[
						'label' => __( 'Title ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::WYSIWYG,
						'default' => __( '<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>', 'ova-framework' ),
						'row' => 2,
					]
				);

				$repeater_ver_2->add_control(
					'icon',
					[
						'label' => __( 'Icon ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => __( 'icon_quotations_alt2', 'ova-framework' ),
						'placeholder' => __( 'Class Font Elegant', 'ova-framework' ),
						'row' => 2,
					]
				);

				$repeater_ver_2->add_control(
					'number_star',
					[
						'label' => __( 'Number Star ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::SELECT,
						'default' => __( '5', 'ova-framework' ),
						'placeholder' => __( 'Class Font Elegant', 'ova-framework' ),
						'options' => [
							5 => 5,
							4 => 4,
							3 => 3,
							2 => 2,
							1 => 1
						],
					]
				);

				$this->add_control(
					'tabs_testimonial_ver_2',
					[
						'label' => __( 'Items Testimonial', 'ova-framework' ),
						'type' => Controls_Manager::REPEATER,
						'fields' => $repeater_ver_2->get_controls(),
						'title_field' => '{{{ title }}}',
						'condition' => [
							'version_testimonial' => 'testimonial_version_2',
						],
					]
				);

		$this->end_controls_section();
		#################### section controll icon ###############################

		############################ end section content  ##############################



		/*****************************************************************
						START SECTION ADDITIONAL
		******************************************************************/

		$this->start_controls_section(
			'section_additional_options',
			[
				'label' => __( 'Additional Options', 'ova-framework' ),
			]
		);


		/***************************  VERSION 1 ***********************/
			$this->add_control(
				'margin_items_ver_1',
				[
					'label' => __( 'Margin Right Items', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 30,
					'condition' => [
						'version_testimonial' => 'testimonial_version_1',
					],
				]
				
			);

			

			$this->add_control(
				'slides_to_scroll_ver_1',
				[
					'label' => __( 'Slides to Scroll', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'description' => __( 'Set how many slides are scrolled per swipe.', 'ova-framework' ),
					'default' => '1',
					'options' => [1,2,3,4,5,6,7,8,9,10],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_1',
					],
				]
			);

			$this->add_control(
				'pause_on_hover_ver_1',
				[
					'label' => __( 'Pause on Hover', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_1',
					],
				]
			);


			$this->add_control(
				'infinite_ver_1',
				[
					'label' => __( 'Infinite Loop', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_1',
					],
				]
			);

			$this->add_control(
				'autoplay_ver_1',
				[
					'label' => __( 'Autoplay', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_1',
					],
				]
			);

			$this->add_control(
				'autoplay_speed_ver_1',
				[
					'label' => __( 'Autoplay Speed', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 3000,
					'step' => 500,
					'condition' => [
						'autoplay' => 'yes',
					],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_1',
						'autoplay_ver_1' => 'yes',
					],
				]
			);

			$this->add_control(
				'smartspeed_ver_1',
				[
					'label'   => __( 'Smart Speed', 'ova-framework' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 500,
					'condition' => [
						'version_testimonial' => 'testimonial_version_1',
					],
				]
			);

			######################## END VERSION 1 ##########################

			/***************************  VERSION 2 ***********************/


			$this->add_control(
				'margin_items_ver_2',
				[
					'label' => __( 'Margin Right Items', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 30,
					'condition' => [
						'version_testimonial' => 'testimonial_version_2',
					],
				]
				
			);

			

			$this->add_control(
				'slides_to_scroll_ver_2',
				[
					'label' => __( 'Slides to Scroll', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'description' => __( 'Set how many slides are scrolled per swipe.', 'ova-framework' ),
					'default' => '1',
					'options' => [1,2,3,4,5,6,7,8,9,10],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_2',
					],
				]
			);

			$this->add_control(
				'pause_on_hover_ver_2',
				[
					'label' => __( 'Pause on Hover', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_2',
					],
				]
			);


			$this->add_control(
				'infinite_ver_2',
				[
					'label' => __( 'Infinite Loop', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_2',
					],
				]
			);

			$this->add_control(
				'autoplay_ver_2',
				[
					'label' => __( 'Autoplay', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_2',
					],
				]
			);

			$this->add_control(
				'autoplay_speed_ver_2',
				[
					'label' => __( 'Autoplay Speed', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 3000,
					'step' => 500,
					'condition' => [
						'autoplay' => 'yes',
					],
					'frontend_available' => true,
					'condition' => [
						'version_testimonial' => 'testimonial_version_2',
						'autoplay_ver_2' => 'yes',
					],
				]
			);

			$this->add_control(
				'smartspeed_ver_2',
				[
					'label'   => __( 'Smart Speed', 'ova-framework' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 500,
					'condition' => [
						'version_testimonial' => 'testimonial_version_2',
					],
				]
			);

			######################   end version 2 #######################

		$this->end_controls_section();
		#########################    END SECTION ADDITIONAL    #########################

		/*******************************************************************************
								TAB STYLE 
		********************************************************************************/

		/*******************************************************************************
								VERSION 1
		********************************************************************************/

		/*************  section controll Navigation. *******************/
		$this->start_controls_section(
			'section_navigation_ver_2',
			[
				'label' => __( 'Navigation', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_2',
				],
			]
		);

			$this->add_control(
				'navigation_size_ver_2',
				[
					'label' => __( 'Font Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-nav i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
			

			$this->add_control(
				'navigation_color_ver_2',
				[
					'label' => __( 'Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-nav i' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'navigation_hover_color_ver_2',
				[
					'label' => __( 'Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-nav .owl-next:hover i, 
						{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-nav .owl-prev:hover i' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'navigation_background_color_ver_2',
				[
					'label' => __( 'Background Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-nav .owl-next' => 'background-color : {{VALUE}}!important;',
					],
				]
			);
			$this->add_control(
				'navigation_background_hover_color_ver_2',
				[
					'label' => __( 'Background Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-nav .owl-prev:hover, 
						{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-nav .owl-next:hover' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

			$this->add_control(
				'navigation_color_border_ver_2',
				[
					'label' => __( 'Color Border Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-nav .owl-prev' =>  'border-color : {{VALUE}}!important;',
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-nav .owl-next' => 'border-color : {{VALUE}}!important;',
					],
				]
			);


		$this->end_controls_section();
		###############  end section Navigation ###############

		/*************  section controll Dots. *******************/
		$this->start_controls_section(
			'section_dot_ver_2',
			[
				'label' => __( 'Dots', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_2',
				],
			]
		);

			$this->add_control(
				'dot_size_ver_2',
				[
					'label' => __( 'Size Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 50,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dot_space_ver_2',
				[
					'label' => __( 'Space Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 50,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-dots .owl-dot' => 'margin-right: {{SIZE}}{{UNIT}};',
					],
				]
			);



			$this->add_control(
				'dot_background_color_ver_2',
				[
					'label' => __( 'Background Color Dot', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-dots .owl-dot' => 'background-color : {{VALUE}}!important;',
					],
				]
			);
			$this->add_control(
				'dot_background_active_color_ver_2',
				[
					'label' => __( 'Background Color Active Dot', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-dots .owl-dot.active' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

			$this->add_control(
				'dot_color_border_ver_2',
				[
					'label' => __( 'Color Border Dot', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-dots .owl-dot' => 'border-color : {{VALUE}}!important;',
					],
				]
			);


			$this->add_responsive_control(
				'dot_margin_ver_2',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'dot_padding_ver_2',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .owl-carousel .owl-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section Dots ###############

		/*************  section controll quote. *******************/
		$this->start_controls_section(
			'section_quote_ver_2',
			[
				'label' => __( 'Quote', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_2',
				],
			]
		);

			$this->add_control(
				'quote_font_size_ver_2',
				[
					'label' => __( 'Font Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .title-testimo .icon-quote' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
			

			$this->add_control(
				'quote_color_ver_2',
				[
					'label' => __( 'Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .title-testimo .icon-quote' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'quote_margin_ver_2',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .title-testimo' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'quote_padding_ver_2',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .title-testimo' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section quote  ###############


		/*************  section controll content. *******************/
		$this->start_controls_section(
			'section_content_ver_2',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_2',
				],
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'content_typography_ver_2',
					'selector' => '{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .content-testimo p',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'content_color_ver_2',
				[
					'label' => __( 'Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .content-testimo p' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'content_margin_ver_2',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .content-testimo' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'content_padding_ver_2',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .content-testimo' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section content  ###############

		/*************  section controll author. *******************/
		$this->start_controls_section(
			'section_author_ver_2',
			[
				'label' => __( 'Author', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_2',
				],
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'author_typography_ver_2',
					'selector' => '{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .more .author',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'author_color_ver_2',
				[
					'label' => __( 'Color Author', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .more .author' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'author_margin_ver_2',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'author_padding_ver_2',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_2 .list-testimonial .testimonial-item .more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section author  ###############

		###########################   END VERSION 1  #############################




		/*******************************************************************************
								VERSION 2
		********************************************************************************/

		/*************  section controll Dots. *******************/
		$this->start_controls_section(
			'section_dot_ver_1',
			[
				'label' => __( 'Dots', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_1',
				],
			]
		);

			$this->add_control(
				'dot_size_ver_1',
				[
					'label' => __( 'Size Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 50,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .owl-carousel .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dot_space_ver_1',
				[
					'label' => __( 'Space Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 50,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .owl-carousel .owl-dots .owl-dot' => 'margin-right: {{SIZE}}{{UNIT}};',
					],
				]
			);



			$this->add_control(
				'dot_background_color_ver_1',
				[
					'label' => __( 'Background Color Dot', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .owl-carousel .owl-dots .owl-dot' => 'background-color : {{VALUE}}!important;',
					],
				]
			);
			$this->add_control(
				'dot_background_active_color_ver_1',
				[
					'label' => __( 'Background Color Active Dot', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .owl-carousel .owl-dots .owl-dot.active' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

			$this->add_control(
				'dot_color_border_ver_1',
				[
					'label' => __( 'Color Border Dot', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .owl-carousel .owl-dots .owl-dot' => 'border-color : {{VALUE}}!important;',
					],
				]
			);


			$this->add_responsive_control(
				'dot_margin_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .owl-carousel .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'dot_padding_ver_1',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .owl-carousel .owl-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section Dots ###############

		/*************  section controll title. *******************/
		$this->start_controls_section(
			'section_title_ver_1',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_1',
				],
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_ver_1',
					'selector' => '{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .title-testimo .title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'title_color_ver_1',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .title-testimo .title' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'title_margin_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .title-testimo .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'title_padding_ver_2',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .title-testimo .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section title  ###############

		/*************  section controll quote. *******************/
		$this->start_controls_section(
			'section_quote_ver_1',
			[
				'label' => __( 'Quote', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_1',
				],
			]
		);

			$this->add_control(
				'quote_font_size_ver_1',
				[
					'label' => __( 'Font Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .title-testimo .icon-quote i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
			

			$this->add_control(
				'quote_color_ver_1',
				[
					'label' => __( 'Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .title-testimo .icon-quote i' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'quote_margin_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .title-testimo .icon-quote' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'quote_padding_ver_1',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .title-testimo .icon-quote' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section quote  ###############

		/*************  section controll content. *******************/
		$this->start_controls_section(
			'section_content_ver_1',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_1',
				],
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'content_typography_ver_1',
					'selector' => '{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .content-testimo p',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'content_color_ver_1',
				[
					'label' => __( 'Color Content', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .content-testimo p' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'content_margin_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .content-testimo' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'content_padding_ver_1',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .content-testimo' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section content  ###############

		/*************  section controll author. *******************/
		$this->start_controls_section(
			'section_author_ver_1',
			[
				'label' => __( 'Author', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_1',
				],
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'author_typography_ver_1',
					'selector' => '{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .more .author',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'author_color_ver_1',
				[
					'label' => __( 'Color Author', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'
						{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .more .author' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'author_margin_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .more .author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'author_padding_ver_1',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .more .author' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section author  ###############


		/*************  section controll Star. *******************/
		$this->start_controls_section(
			'section_star_ver_1',
			[
				'label' => __( 'Star', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_testimonial' => 'testimonial_version_1',
				],
			]
		);

			$this->add_control(
				'star_size_ver_1',
				[
					'label' => __( 'Size Star', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .more .star i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'star_space_ver_1',
				[
					'label' => __( 'Space Star', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 50,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .more .star i' => 'margin-right: {{SIZE}}{{UNIT}};',
					],
				]
			);



			$this->add_control(
				'star_color_ver_1',
				[
					'label' => __( 'Color Star', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .more .star i' => 'color : {{VALUE}}!important;',
					],
				]
			);


			$this->add_responsive_control(
				'star_margin_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .more .star' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'star_padding_ver_1',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-testimonial.testimonial_version_1 .list-testimonial .testimonial-item .more .star' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		###############  end section star ###############

		###########################   END VERSION 2  #############################



	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$version_testimonial = $settings['version_testimonial'];
		$tabs_testimonial = $data_options = [];
		switch ($version_testimonial) {
			case "testimonial_version_1" : {
				$tabs_testimonial 					= $settings['tabs_testimonial_ver_1'];

				$data_options['slideBy'] 			= $settings['slides_to_scroll_ver_1'];
				$data_options['margin'] 			= $settings['margin_items_ver_1'];
				$data_options['autoplayHoverPause'] = $settings['pause_on_hover_ver_1'] === 'yes' ? true : false;
				$data_options['loop'] 			 	= $settings['infinite_ver_1'] === 'yes' ? true : false;
				$data_options['autoplay'] 			= $settings['autoplay_ver_1'] === 'yes' ? true : false;
				$data_options['autoplayTimeout']	= $settings['autoplay_speed_ver_1'];
				$data_options['smartSpeed']			= $settings['smartspeed_ver_1'];
				break;
			}
			case "testimonial_version_2" : {
				$tabs_testimonial 					= $settings['tabs_testimonial_ver_2'];

				$data_options['slideBy'] 			= $settings['slides_to_scroll_ver_2'];
				$data_options['margin'] 			= $settings['margin_items_ver_2'];
				$data_options['autoplayHoverPause'] = $settings['pause_on_hover_ver_2'] === 'yes' ? true : false;
				$data_options['loop'] 			 	= $settings['infinite_ver_2'] === 'yes' ? true : false;
				$data_options['autoplay'] 			= $settings['autoplay_ver_2'] === 'yes' ? true : false;
				$data_options['autoplayTimeout']	= $settings['autoplay_speed_ver_2'];
				$data_options['smartSpeed']			= $settings['smartspeed_ver_2'];
				break;
			}
		}

		?>
		<div class="ova-testimonial <?php echo $version_testimonial ?>">
			<div class="list-testimonial testimo-slider owl-carousel" data-options="<?php echo esc_html__(json_encode($data_options)) ?>">
				<?php if (!empty($tabs_testimonial)) : foreach ($tabs_testimonial as $item_testimonial) : ?>
					<div class="testimonial-item">
						<div class="title-testimo">
							<?php if ($version_testimonial === 'testimonial_version_1') : ?>
								<h3 class="title second_font"><?php echo $item_testimonial['title']  ?></h3>
							<?php endif ?>
							<span class="icon-quote"><i class="<?php echo $item_testimonial['icon'] ?>"></i></span>
						</div>
						<div class="content-testimo">
							<?php echo $item_testimonial['content'] ?>
						</div>
						<div class="more">
							<span class="author"><?php echo $item_testimonial['author']  ?></span>
							<?php if ($version_testimonial === 'testimonial_version_1') : ?>
								<span class="star">
									<?php if (!empty($item_testimonial['number_star'])) : for($i=1;$i<=$item_testimonial['number_star'];$i++) : ?>
										<i class="fas fa-star"></i>
									<?php endfor; endif; ?>
								</span>
							<?php endif ?>
						</div>
					</div>
				<?php endforeach; endif; ?>
			</div>
		</div>

		<?php
	}
}
