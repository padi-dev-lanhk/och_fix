<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_price_table extends Widget_Base {

	public function get_name() {
		return 'ova_price_table';
	}

	public function get_title() {
		return __( 'Price Table', 'ova-framework' );
	}

	public function get_icon() {
		return 'fa fa-archive';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			$this->add_control(
				'active',
				[
					'label' => __( 'Active', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
				]
			);

			$this->add_control(
				'title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'SMALL ROOM', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
				]
			);

			$this->add_control(
				'price',
				[
					'label' => __( 'Price', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '$10', 'ova-framework' ),
					'placeholder' => __( 'Type your price here', 'ova-framework' ),
				]
			);

			$this->add_control(
				'per_time',
				[
					'label' => __( 'Time Rent', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Day', 'ova-framework' ),
					'placeholder' => __( 'Type your time rent here', 'ova-framework' ),
				]
			);

			$this->add_control(
				'link',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'Type link here', 'ova-framework' ),
					'show_external' => true,
					'default' => [
						'url' => '#',
						'is_external' => false,
						'nofollow' => false,
					],
				]
			);

			$repeater = new \Elementor\Repeater();

				$repeater->add_control(
					'info_room',
					[
						'label' => __( 'Info Room ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'rows' => 2,
						'default' => __( 'Free Wifi', 'ova-framework' ),
					]
				);

			$this->add_control(
				'tab_info',
				[
					'label' => __( 'Tab Info Room', 'ova-framework' ),
					'type' => Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'info_room' => __('Free Wifi'),
						],
						[
							'info_room' => __('Great See View'),
						],
						[
							'info_room' => __('Home Made Food'),
						],
						[
							'info_room' => __('...'),
						],
					],
					'title_field' => '{{{ info_room }}}',
				]
			);
			

		$this->end_controls_section();
		#################### section controll background  ###############################

		/*******************************************************************************
						TAB STYLE SERVICE VERSION 1
		********************************************************************************/

		/*************  section controll title *******************/

		
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .ova-price-table .wp-title .title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-title .title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_title',
				[
					'label' => __( 'Color Hover Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table.active .wp-title .title a' => 'color : {{VALUE}};',
					],
				]
			);

			


			$this->add_responsive_control(
				'margin_title',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		###############  end section controll cover title. ###############


		/*************  section controll price *******************/

		
		$this->start_controls_section(
			'section_price',
			[
				'label' => __( 'Price', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'price_typography',
					'label' => 'Price',
					'selector' => '{{WRAPPER}} .ova-price-table .wp-price .price',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'time_typography',
					'label' => 'Time',
					'selector' => '{{WRAPPER}} .ova-price-table .wp-price .times .separator, {{WRAPPER}} .ova-price-table .wp-price .times .per_time',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_price',
				[
					'label' => __( 'Color Price', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price .price' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_price',
				[
					'label' => __( 'Color Hover Price', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table.active .wp-price .price' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_time',
				[
					'label' => __( 'Color Time', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price .times .separator' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova-price-table .wp-price .times .per_time' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_time',
				[
					'label' => __( 'Color Hover Time', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table.active .wp-price .times .separator' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova-price-table.active .wp-price .times .per_time' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color_hover',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table.active .wp-price' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'thin',
				[
					'label' => __( 'Thin border Price', 'plugin-domain' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 20,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price' => 'border-width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'border_color_price',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price' => 'border-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'border_color_price_hover',
				[
					'label' => __( 'Color Hover Time', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table.active .wp-price' => 'border-color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_prices',
				[
					'label' => __( 'Margin Wp Price', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_prices',
				[
					'label' => __( 'Padding WP Price', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_price',
				[
					'label' => __( 'Margin Price', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price .price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_price',
				[
					'label' => __( 'Padding Price', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price .price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_time',
				[
					'label' => __( 'Margin Time', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price .times' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_time',
				[
					'label' => __( 'Padding Time', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-price .times' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		###############  end section controll price. ###############


		/*************  section controll info *******************/

		
		$this->start_controls_section(
			'section_info',
			[
				'label' => __( 'Info', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'info_typography',
					'selector' => '{{WRAPPER}} .ova-price-table .wp-info .info .item',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_info',
				[
					'label' => __( 'Color Info', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-info .info .item' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_hover_info',
				[
					'label' => __( 'Color Hover Info', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table.active .wp-info .info .item' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_info',
				[
					'label' => __( 'Margin Info', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-info .info .item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_info',
				[
					'label' => __( 'Padding Info', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table .wp-info .info .item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		###############  end section controll info . ###############


		/*************  section controll background element *******************/

		
		$this->start_controls_section(
			'section_background_item',
			[
				'label' => __( 'Background', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


			$this->add_control(
				'background_color_item',
				[
					'label' => __( 'Background Color Item', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color_item_hover',
				[
					'label' => __( 'Background Color Item Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table.active' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'thin_border_item',
				[
					'label' => __( 'Thin border Item', 'plugin-domain' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 20,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-price-table' => 'border-width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'border_color_item',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table' => 'border-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'border_color_item_hover',
				[
					'label' => __( 'Border Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-price-table.active' => 'border-color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();

		###############  end section controll background element. ###############

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$title = $price = $per_time = $class_active = "";
		$tab_info = [];

		$target = $settings['link']['is_external'] ? ' target = _blank ' : '';
		$nofollow = $settings['link']['nofollow'] ? ' rel = nofollow ' : '';
		$url = $settings['link']['url'];
		$title = $settings['title'];
		$price = $settings['price'];
		$per_time = $settings['per_time'];
		$class_active = $settings['active'] === 'yes' ? ' active ' : '';
		$tab_info = $settings['tab_info'];
		

		?>

		<div class="ova-price-table <?php echo esc_attr($class_active) ?>">
			<div class="wp-title">
				<h3 class="title"><a class="second_font" href="<?php echo esc_url($url) ?>" <?php echo esc_attr($target) . esc_attr($nofollow)  ?>><?php echo esc_html($title) ?></a></h3>
			</div>
			<div class="wp-price">
				<span class="price second_font"><?php echo esc_html($price) ?></span>
				<div class="times">
					<span class="separator">&#47;</span>
					<span class="per_time second_font"><?php echo esc_html($per_time) ?></span>
				</div>
			</div>
			<div class="wp-info">
				<ul class="info">
					<?php if (!empty($tab_info)) : foreach ($tab_info as $info) : ?>
						<li class="item"><?php echo esc_html($info['info_room']) ?></li>
					<?php endforeach; endif; ?>
				</ul>
			</div>
		</div>
		

		<?php
	}
}
