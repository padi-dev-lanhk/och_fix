<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_blog_slider extends Widget_Base {

	public function get_name() {
		return 'ova_blog_slider';
	}

	public function get_title() {
		return __( 'Blog Slider', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-carousel';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		$args = array(
		  'orderby' => 'name',
		  'order' => 'ASC'
		  );

		$categories=get_categories($args);
		$cate_array = array();
		$arrayCateAll = array( 'all' => 'All categories ' );
		if ($categories) {
			foreach ( $categories as $cate ) {
				$cate_array[$cate->cat_name] = $cate->slug;
			}
		} else {
			$cate_array["No content Category found"] = 0;
		}

		//CHOOSES BLOG VERSION 
		$this->start_controls_section(
			'section_choose_version',
			[
				'label' => __( 'Chooses Blog Version', 'ova-framework' ),
			]
		);
			$this->add_control(
				'version_blog',
				[
					'label' => __( 'Choose Blog Version', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'blog_slider_1',
					'options' => [
						'blog_slider_1' => __( 'Blog Slider Version 1', 'ova-framework' ),
						'blog_slider_2' => __( 'Blog Slider Version 2', 'ova-framework' ),
					],
				]
			);
			$slides_to_show = range( 1, 10 );
			$slides_to_show = array_combine( $slides_to_show, $slides_to_show );
		$this->end_controls_section();

		/*****************************************************************
						START BLOG SLIDER VERSION 1
			******************************************************************/
		$this->start_controls_section(
			'section_content_ver_1',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'condition' => [
					'version_blog' => 'blog_slider_1',
				],
			]
		);

			$this->add_control(
				'category_ver_1',
				[
					'label' => __( 'Category', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'all',
					'condition' => [
						'version_blog' => 'blog_slider_1',
					],
					'options' => array_merge($arrayCateAll,$cate_array),
				]
			);

			$this->add_control(
				'total_count_ver_1',
				[
					'label' => __( 'Total Post', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 4,
					'min' => 4,
					'condition' => [
						'version_blog' => 'blog_slider_1',
					],
				]
			);

			$this->add_control(
				'show_title_ver_1',
				[
					'label' => __( 'Show Title', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'version_blog' => 'blog_slider_1',
					],
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_date_ver_1',
				[
					'label' => __( 'Show Date', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'version_blog' => 'blog_slider_1',
					],
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_excerpt_ver_1',
				[
					'label' => __( 'Show Excerpt', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'version_blog' => 'blog_slider_1',
					],
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_read_more_ver_1',
				[
					'label' => __( 'Show Read More', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'version_blog' => 'blog_slider_1',
					],
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'icon_overlay_ver_1',
				[
					'label' => __( 'Icon Hover Image (font elegant)', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => 'arrow_right',
					'condition' => [
						'version_blog' => 'blog_slider_1',
					],
				]
			);

			$this->add_control(
				'text_read_more_ver_1',
				[
					'label' => __( 'Text Read More', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'Read More',
					'condition' => [
						'version_blog' => 'blog_slider_1',
					],
					'placeholder' => 'Text',
				]
			);

		$this->end_controls_section();
		//END SECTION CONTENT

		/*****************************************************************
						START SECTION ADDITIONAL
		******************************************************************/

		$this->start_controls_section(
			'section_additional_options_ver_1',
			[
				'label' => __( 'Additional Options', 'ova-framework' ),
				'condition' => [
					'version_blog' => 'blog_slider_1',
				],
			]
		);

			$this->add_control(
				'margin_ver_1',
				[
					'label' => __( 'Margin Right Item', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 0,
					'step' => 1,
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'navigation_ver_1',
				[
					'label' => __( 'Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'dots',
					'options' => [
						'dots' => __( 'Dots', 'ova-framework' ),
						'navs' => __( 'Navs', 'ova-framework' ),
						'both' => __( 'Navs and Dots', 'ova-framework' ),
						'none' => __( 'None', 'ova-framework' ),
					],
					'frontend_available' => true,
					'condition' => [
						'version_blog' => 'blog_slider_1',
					],
				]
			);

			$this->add_control(
				'slides_to_scroll_ver_1',
				[
					'label' => __( 'Slides to Scroll', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'description' => __( 'Set how many slides are scrolled per swipe.', 'ova-framework' ),
					'default' => '1',
					'options' => $slides_to_show,
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'pause_on_hover_ver_1',
				[
					'label' => __( 'Pause on Hover', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);


			$this->add_control(
				'infinite_ver_1',
				[
					'label' => __( 'Infinite Loop', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_ver_1',
				[
					'label' => __( 'Autoplay', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_speed_ver_1',
				[
					'label' => __( 'Autoplay Speed', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 3000,
					'step' => 500,
					'condition' => [
						'autoplay_ver_1' => 'yes',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'smart_speed_ver_1',
				[
					'label' => __( 'Smart Speed', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 500,
					'step' => 100,
					'frontend_available' => true,
				]
			);

		$this->end_controls_section();
		//END SECTION ADDITIONAL

		//END SECTION CONTENT BLOG VERSION 1


		/*****************************************************************
						START BLOG SLIDER VERSION 2
		******************************************************************/
		$this->start_controls_section(
			'section_content_ver_2',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'condition' => [
					'version_blog' => 'blog_slider_2',
				],
			]
		);
			$this->add_control(
				'category_ver_2',
				[
					'label' => __( 'Category', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'all',
					'condition' => [
						'version_blog' => 'blog_slider_2',
					],
					'options' => array_merge($arrayCateAll,$cate_array),
				]
			);

			$this->add_control(
				'total_count_ver_2',
				[
					'label' => __( 'Total Post', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 4,
					'min' => 4,
					'condition' => [
						'version_blog' => 'blog_slider_2',
					],
				]
			);

			

			$this->add_control(
				'show_title_ver_2',
				[
					'label' => __( 'Show Title', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'version_blog' => 'blog_slider_2',
					],
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_date_ver_2',
				[
					'label' => __( 'Show Date', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'version_blog' => 'blog_slider_2',
					],
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_excerpt_ver_2',
				[
					'label' => __( 'Show Excerpt', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'version_blog' => 'blog_slider_2',
					],
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_read_more_ver_2',
				[
					'label' => __( 'Show Read More', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'version_blog' => 'blog_slider_2',
					],
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'icon_overlay_ver_2',
				[
					'label' => __( 'Icon Hover Image (font elegant)', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => 'arrow_right',
					'condition' => [
						'version_blog' => 'blog_slider_2',
					],
				]
			);

			$this->add_control(
				'text_read_more_ver_2',
				[
					'label' => __( 'Text Read More', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'Read More',
					'condition' => [
						'version_blog' => 'blog_slider_2',
					],
					'placeholder' => 'Text',
				]
			);

		$this->end_controls_section();
		//END SECTION CONTENT VERSION 2

		/*****************************************************************
						START SECTION ADDITIONAL VERSION 2
		******************************************************************/
	

		$this->start_controls_section(
			'section_additional_options_ver_2',
			[
				'label' => __( 'Additional Options', 'ova-framework' ),
				'condition' => [
					'version_blog' => 'blog_slider_2',
				],
			]
		);

			$this->add_control(
				'margin_ver_2',
				[
					'label' => __( 'Margin Right Item', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 30,
					'step' => 1,
					'frontend_available' => true,
				]
			);
			$this->add_control(
				'navigation_ver_2',
				[
					'label' => __( 'Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'dots',
					'options' => [
						'dots' => __( 'Dots', 'ova-framework' ),
						'navs' => __( 'Navs', 'ova-framework' ),
						'both' => __( 'Navs and Dots', 'ova-framework' ),
						'none' => __( 'None', 'ova-framework' ),
					],
					'frontend_available' => true,
					'condition' => [
						'version_blog' => 'blog_slider_2',
					],
				]
			);

			$this->add_control(
				'slides_to_scroll_ver_2',
				[
					'label' => __( 'Slides to Scroll', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'description' => __( 'Set how many slides are scrolled per swipe.', 'ova-framework' ),
					'default' => '1',
					'options' => $slides_to_show,
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'pause_on_hover_ver_2',
				[
					'label' => __( 'Pause on Hover', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);


			$this->add_control(
				'infinite_ver_2',
				[
					'label' => __( 'Infinite Loop', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_ver_2',
				[
					'label' => __( 'Autoplay', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_speed_ver_2',
				[
					'label' => __( 'Autoplay Speed', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 3000,
					'step' => 500,
					'condition' => [
						'autoplay_ver_2' => 'yes',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'smart_speed_ver_2',
				[
					'label' => __( 'Smart Speed', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 500,
					'step' => 100,
					'frontend_available' => true,
				]
			);


		$this->end_controls_section();
		//END SECTION ADDITIONAL 

		//END SECTION BLOG SLIDER VERSION 2

		/*******************************************************************************
						TAB STYLE BLOG SLIDER 1
		********************************************************************************/


		/*************  section controll Navigation. *******************/
		$this->start_controls_section(
			'section_navigation_ver_1',
			[
				'label' => __( 'Navigation', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_1'],
				],
			]
		);
			

			$this->add_control(
				'navigation_fontsize_ver_1',
				[
					'label' => __( 'Font Size Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 40,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'font-size: {{SIZE}}{{UNIT}}!important;',
					],
				]
			);

			$this->add_control(
				'navigation_position_ver_1',
				[
					'label' => __( 'Position Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => -200,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 10,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev' => 'right: calc(100% + {{SIZE}}{{UNIT}});',
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'left: calc(100% + {{SIZE}}{{UNIT}});',
					],
				]
			);

			$this->add_control(
				'navigation_width_height_ver_1',
				[
					'label' => __( 'Width And Height Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 50,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'navigation_border_radius_ver_1',
				[
					'label' => __( 'Border Radius Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'navigation_color_ver_1',
				[
					'label' => __( 'Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,1)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'navigation_hover_color_ver_1',
				[
					'label' => __( 'Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,1)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev:hover, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'navigation_background_color_ver_1',
				[
					'label' => __( 'Background Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,0)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'background-color : {{VALUE}}!important;',
					],
				]
			);
			$this->add_control(
				'navigation_background_hover_color_ver_1',
				[
					'label' => __( 'Background Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,0)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev:hover, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next:hover' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

		$this->end_controls_section();
		###############  end section Navigation ###############


		/*************  section controll dots. *******************/
		$this->start_controls_section(
			'section_dots_ver_1',
			[
				'label' => __( 'Dots', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_1'],
				],
			]
		);

			$this->add_control(
				'dots_fontsize_ver_1',
				[
					'label' => __( 'Font Size Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 16,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_position_ver_1',
				[
					'label' => __( 'Position Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 70,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots' => 'margin-top: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_width_height_ver_1',
				[
					'label' => __( 'Width And Height Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 55,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_border_radius_ver_1',
				[
					'label' => __( 'Border Radius Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_color_ver_1',
				[
					'label' => __( 'Color Dots', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot:before' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'dots_color_hover_ver_1',
				[
					'label' => __( 'Color Dots Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot:hover:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'dots_background_color_ver_1',
				[
					'label' => __( 'Background Color Dots', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

			$this->add_control(
				'dots_background_hover_color_ver_1',
				[
					'label' => __( 'Background Color Hover Dots', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot:hover' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

		$this->end_controls_section();
		###############  end section Dots ###############

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_ver_1',
			[
				'label' => __( 'Cover Image Hover', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_1'],
				],
			]
		);

			$this->add_control(
				'cover_image_background_color_ver_1',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,0.7)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .post-item .post-media .overlay:hover' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'cover_image_fontsize_ver_1',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 70,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .post-item .post-media .overlay i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'icon_color_ver_1',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .post-item .post-media .overlay i' => 'color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll cover image. ###############


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_style_ver_1',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_1'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_ver_1_typography',
				'selector' => '{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'title_color_ver_1',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color_ver_1',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin_ver_1',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding_ver_1',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll title. ###############


		/*************  section controll date. *******************/

		$this->start_controls_section(
			'section_date_style_ver_1',
			[
				'label' => __( 'Date', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_1'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'date_ver_1_typography',
				'selector' => '{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-meta .post-date',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'date_color_ver_1',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "rgba(0,0,0,0.6)",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-meta .post-date' => 'color : {{VALUE}};',
				],
			]
		);
		

		$this->add_responsive_control(
			'date_margin_ver_1',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-meta .post-date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_padding_ver_1',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-meta .post-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll date. ###############


		/*************  section controll excerpt. *******************/

		$this->start_controls_section(
			'section_excerpt_style_ver_1',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_1'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_ver_1_typography',
				'selector' => '{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-excerpt p',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'excerpt_color_ver_1',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-excerpt p' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'excerpt_margin_ver_1',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-excerpt p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_padding_ver_1',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-excerpt p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll excerpt. ###############

		/*************  section controll readmore. *******************/

		$this->start_controls_section(
			'section_readmore_style_ver_1',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_1'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'readmore_ver_1_typography',
				'selector' => '{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'readmore_color_ver_1',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'readmore_hover_color_ver_1',
			[
				'label' => __( 'Read More Hover Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a:hover' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'readmore_margin_ver_1',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'readmore_padding_ver_1',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll read more. ###############

		//END SECTION STYLE BLOG SLIDER VERSION 1

		/*******************************************************************************
						TAB STYLE BLOG SLIDER 2
		********************************************************************************/

		/*************  section controll Navigation. *******************/
		$this->start_controls_section(
			'section_navigation_ver_2',
			[
				'label' => __( 'Navigation', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_2'],
				],
			]
		);

			$this->add_control(
				'navigation_fontsize_ver_2',
				[
					'label' => __( 'Font Size Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 40,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'font-size: {{SIZE}}{{UNIT}}!important;',
					],
				]
			);

			$this->add_control(
				'navigation_position_ver_2',
				[
					'label' => __( 'Position Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => -200,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 10,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev' => 'right: calc(100% + {{SIZE}}{{UNIT}});',
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'left: calc(100% + {{SIZE}}{{UNIT}});',
					],
				]
			);

			$this->add_control(
				'navigation_width_height_ver_2',
				[
					'label' => __( 'Width And Height Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 50,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'navigation_border_radius_ver_2',
				[
					'label' => __( 'Border Radius Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'navigation_color_ver_2',
				[
					'label' => __( 'Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,1)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'navigation_hover_color_ver_2',
				[
					'label' => __( 'Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,1)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev:hover, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'navigation_background_color_ver_2',
				[
					'label' => __( 'Background Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,0)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

			$this->add_control(
				'navigation_background_hover_color_ver_2',
				[
					'label' => __( 'Background Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,0)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-prev:hover, 
						{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-nav .owl-next:hover' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

		$this->end_controls_section();
		###############  end section Navigation ###############


		/*************  section controll Navigation. *******************/
		$this->start_controls_section(
			'section_dots_ver_2',
			[
				'label' => __( 'Dots', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_2'],
				],
			]
		);

			$this->add_control(
				'dots_fontsize_ver_2',
				[
					'label' => __( 'Font Size Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 16,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_position_ver_2',
				[
					'label' => __( 'Position Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 70,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots' => 'margin-top: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_width_height_ver_2',
				[
					'label' => __( 'Width And Height Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 55,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_border_radius_ver_2',
				[
					'label' => __( 'Border Radius Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_color_ver_2',
				[
					'label' => __( 'Color Dots', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot:before' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'dots_color_hover_ver_2',
				[
					'label' => __( 'Color Dots Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot:hover:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'dots_background_color_ver_2',
				[
					'label' => __( 'Background Color Dots', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

			$this->add_control(
				'dots_background_hover_color_ver_2',
				[
					'label' => __( 'Background Color Dots Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .owl-carousel .owl-dots .owl-dot:hover' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

		$this->end_controls_section();
		###############  end section Dots ###############

		$this->start_controls_section(
			'section_cover_image_ver_2',
			[
				'label' => __( 'Cover Image Hover', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_2'],
				],
			]
		);

			$this->add_control(
				'cover_image_background_color_ver_2',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,0.7)',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .post-item .post-media .overlay:hover' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'cover_image_fontsize_ver_2',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 70,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .post-item .post-media .overlay i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'icon_color_ver_2',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .post-item .post-media .overlay i' => 'color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll cover image. ###############


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_style_ver_2',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_2'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_ver_2_typography',
				'selector' => '{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'title_color_ver_2',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color_ver_2',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin_ver_2',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding_ver_2',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-title h2 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll title. ###############


		/*************  section controll date. *******************/

		$this->start_controls_section(
			'section_date_style_ver_2',
			[
				'label' => __( 'Date', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_2'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'date_ver_2_typography',
				'selector' => '{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-meta .post-date',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'date_color_ver_2',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "rgba(0,0,0,0.6)",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-meta .post-date' => 'color : {{VALUE}};',
				],
			]
		);
		

		$this->add_responsive_control(
			'date_margin_ver_2',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-meta .post-date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_padding_ver_2',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-meta .post-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll date. ###############


		/*************  section controll excerpt. *******************/

		$this->start_controls_section(
			'section_excerpt_style_ver_2',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_2'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_ver_2_typography',
				'selector' => '{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-excerpt p',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'excerpt_color_ver_2',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-excerpt p' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'excerpt_margin_ver_2',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-excerpt p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_padding_ver_2',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-excerpt p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll excerpt. ###############

		/*************  section controll readmore. *******************/

		$this->start_controls_section(
			'section_readmore_style_ver_2',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_slider_2'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'readmore_ver_2_typography',
				'selector' => '{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'readmore_color_ver_2',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'readmore_hover_color_ver_2',
			[
				'label' => __( 'Read More Hover Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a:hover' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'readmore_margin_ver_2',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'readmore_padding_ver_2',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-slider-element .post-item .content .post-readmore a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll read more. ###############

		//END SECTION STYLE BLOG SLIDER VERSION 2
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$version_blog = $settings['version_blog'];
		
		$category = $total_count = $slide_to_scroll = $show_title = $show_date = $show_excerpt = $show_readmore = $icon_overlay = $text_read_more = $pause_on_hover = $loop = $autoplay = $autoplay_speed = $animate_speed = $nav = "";
		$data_options = [];
		$data_options['items'] = 3;
		switch ( $version_blog ) {
			case "blog_slider_1" : {
				$category = $settings['category_ver_1'];
				$total_count = $settings['total_count_ver_1'];
				$show_title = $settings['show_title_ver_1'];
				$show_date = $settings['show_date_ver_1'];
				$show_excerpt = $settings['show_excerpt_ver_1'];
				$show_readmore = $settings['show_read_more_ver_1'];
				$icon_overlay = $settings['icon_overlay_ver_1'];
				$text_read_more = $settings['text_read_more_ver_1'];

				$nav = $settings['navigation_ver_1'];
				$data_options['margin'] = $settings['margin_ver_1'];
				$data_options['slideBy'] = $settings['slides_to_scroll_ver_1'];
				$data_options['autoplayHoverPause'] = $settings['pause_on_hover_ver_1'] === 'yes' ? true : false;
				$data_options['loop'] = $settings['infinite_ver_1'] === 'yes' ? true : false;
				$data_options['autoplay'] = $settings['autoplay_ver_1'] === 'yes' ? true : false;
				$data_options['autoplayTimeout'] = $settings['autoplay_speed_ver_1'];
				$data_options['smartSpeed'] = $settings['smart_speed_ver_1'];
			}
			break;

			case "blog_slider_2" : {
				$category = $settings['category_ver_2'];
				$total_count = $settings['total_count_ver_2'];
				$show_title = $settings['show_title_ver_2'];
				$show_date = $settings['show_date_ver_2'];
				$show_excerpt = $settings['show_excerpt_ver_2'];
				$show_readmore = $settings['show_read_more_ver_2'];
				$icon_overlay = $settings['icon_overlay_ver_2'];
				$text_read_more = $settings['text_read_more_ver_2'];

				$nav = $settings['navigation_ver_2'];
				$data_options['margin'] = $settings['margin_ver_2'];
				$data_options['slideBy'] = $settings['slides_to_scroll_ver_2'];
				$data_options['autoplayHoverPause'] = $settings['pause_on_hover_ver_2'] === 'yes' ? true : false;
				$data_options['loop'] = $settings['infinite_ver_2'] === 'yes' ? true : false;
				$data_options['autoplay'] = $settings['autoplay_ver_2'] === 'yes' ? true : false;
				$data_options['autoplayTimeout'] = $settings['autoplay_speed_ver_2'];
				$data_options['smartSpeed'] = $settings['smart_speed_ver_2'];
			}
			break;
		}

		switch ($nav) {
			case 'dots':
				$data_options['dots'] = true;
				$data_options['nav'] = false;
				break;

			case 'navs':
				$data_options['nav'] = true;
				$data_options['dots'] = false;
				break;

			case 'both':
				$data_options['dots'] = true;
				$data_options['nav'] = true;
				break;

			case 'none':
				$data_options['dots'] = false;
				$data_options['nav'] = false;
				break;
		}

		$args =array();
		if ($category == 'all') {
			$args=array('post_type' => 'post', 'posts_per_page' => $total_count);
		} else {
			$args=array('post_type' => 'post', 'category_name'=>$category,'posts_per_page' => $total_count);
		}
		$blog = new \WP_Query($args);

		
		?>
		
			<div class="ova-blog-slider-element <?php echo $version_blog ?>">
				
				<div class="list-post-item single-slider owl-carousel" data-options="<?php echo esc_html__(json_encode($data_options)) ?>">
					<?php
						$i = 0;
						if($blog->have_posts()) : while($blog->have_posts()) : $blog->the_post();
							$i++;
							$class_odd_even = ($i % 2 == 0) ? ' even ' : ' odd ';
							$class_first = ($i == 1) ? ' first ' : '';
							$thumbnail_url = wp_get_attachment_image_url(get_post_thumbnail_id() , 'full' );
							$the_time = get_the_time( get_option( 'date_format' ));
					?>
							<div class="post-item <?php echo $class_odd_even . $class_first ?>">
								<div class="post-media" style="background-image: url(<?php echo $thumbnail_url ?>)">
									<a class="overlay" href="<?php the_permalink() ?>">
										<i class="<?php echo $icon_overlay ?>"></i>
									</a>
								</div>
								<div class="content">
									<?php  if ($show_title) : ?>
										<div class="post-title">
											<h2><a class="second_font" href="<?php the_permalink() ?>"><?php echo hozing_custom_text(get_the_title(), 4) ?></a></h2>
										</div>
									<?php endif ?>
									<?php  if ($show_date) : ?>
										<div class="post-meta">
											<span class="post-date"><?php the_time( get_option( 'date_format' )) ?></span>
										</div>
									<?php endif ?>
									<?php  if ($show_excerpt) : ?>
										<div class="post-excerpt">
											<p><?php echo hozing_custom_text(get_the_excerpt(), 12) ?></p>
										</div>
									<?php endif ?>
									<?php  if ($show_readmore) : ?>
										<div class="post-readmore">
											<a href="<?php the_permalink() ?>"><?php echo esc_html__($text_read_more)?></a>
										</div>
									<?php endif ?>
								</div>
							</div>
					<?php
						endwhile; endif; wp_reset_postdata();
					?>
				</div>
				
			</div>
				<!-- end ova-blog -->
		<?php
	}
}
