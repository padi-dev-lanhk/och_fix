<?php if ( !defined( 'ABSPATH' ) ) exit();

require_once( OVACRS_PLUGIN_PATH.'/admin/class_render_table_booking.php' );
require_once( OVACRS_PLUGIN_PATH.'/admin/class_admin_ajax.php' );
require_once( OVACRS_PLUGIN_PATH.'/admin/class_display_table_booking.php' );




// Create Sub-Menu-Page in Woo
add_action('admin_menu', 'hozing_schedule_menu');
function hozing_schedule_menu() {
	add_submenu_page(
	    'edit.php?post_type=product',
	    __( 'Manage Booking', 'ova-hotel' ),
	    __( 'Manage Booking', 'ova-hotel' ),
	    'manage_woocommerce',
	    'manage-booking',
	    'hozing_display_booking'
	);
}

// Add Css in admin
// add_action( 'admin_print_styles', 'load_custom_admin_css' );
add_action( 'admin_footer', 'hotel_add_scripts', 10, 2 );
function hotel_add_scripts(){

 wp_enqueue_style( 'hotel_woo_admin', home_url().'/wp-content/plugins/woocommerce/assets/css/admin.css');
 wp_enqueue_style( 'hotel_booking_admin', OVACRS_PLUGIN_URI.'/admin/admin-style.css');

 wp_enqueue_script('admin_script', OVACRS_PLUGIN_URI.'/admin/admin_script.js', array('jquery'),false,true);
}
