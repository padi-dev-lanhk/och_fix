<?php if ( !defined( 'ABSPATH' ) ) exit();


add_filter( 'woocommerce_display_item_meta', 'ovacrs_filter_woocommerce_display_item_meta', 10, 3 ); 
function ovacrs_filter_woocommerce_display_item_meta( $html, $item, $args ) { 
    
    $html = str_replace('room_check_in', esc_html__('Check in', 'ova-hotel') , $html );
	$html = str_replace('room_check_out', esc_html__('Check out', 'ova-hotel') , $html );
	$html = str_replace('room_adults', esc_html__('Adults', 'ova-hotel') , $html );
	$html = str_replace('room_childrens', esc_html__('Childrens', 'ova-hotel') , $html );
    $html = str_replace('room_rooms', esc_html__('Rooms', 'ova-hotel') , $html );
    $html = str_replace('id_room_code', esc_html__('Room Code', 'ova-hotel') , $html );
    $html = str_replace('ovacrs_total_days', esc_html__(' Total Nights ', 'ova-hotel') , $html );
    $html = str_replace('ovacrs_price_detail', esc_html__(' Price Detail ', 'ova-hotel') , $html );
    
	return $html;
};


// Get Real Quantity 
function get_real_quantity( $product_quantity, $product_id, $room_check_in, $room_check_out  ){

        $ovacrs_cal_real_qr = ovacrs_cal_real_qr( $room_check_in, $room_check_out, $product_id );

        $quantity_text = '';
        if( $ovacrs_cal_real_qr['gl_quantity'] ){
            $quantity_text .= $ovacrs_cal_real_qr['gl_quantity'].' '.esc_html__( 'Night(s)', 'ova-hotel' );
        }
        if( $ovacrs_cal_real_qr['rt_quantity'] ){
            if( $quantity_text != '' ) $quantity_text .= '<br/>';
            $quantity_text .= $ovacrs_cal_real_qr['rt_quantity'].' '.esc_html__( 'Special Night(s)', 'ova-hotel' );
        }
        

    return $quantity_text; 
}


// Get Real Price In Range Time
function get_real_price( $product_price, $product_id, $room_check_in, $room_check_out ){
        
        $ovacrs_cal_real_qr = ovacrs_cal_real_qr( $room_check_in, $room_check_out, $product_id );
        $price_text = '';
        if( $ovacrs_cal_real_qr['gl_price'] && $ovacrs_cal_real_qr['gl_quantity'] ){
            $price_text .= wc_price( $ovacrs_cal_real_qr['gl_price'] ).' '.esc_html__( ' /Night(s)', 'ova-hotel' );
        }
        if( $ovacrs_cal_real_qr['rt_price'] &&  $ovacrs_cal_real_qr['rt_quantity'] ){
            if( $price_text != '' ) $price_text .= '<br/>';
            $price_text .= wc_price( $ovacrs_cal_real_qr['rt_price'] ).' '.esc_html__( ' / Special Night(s)', 'ova-hotel' );
        }
    

    return $price_text; 
}


// Filter Quantity for Cart
add_filter( 'woocommerce_widget_cart_item_quantity', 'ovacrs_woocommerce_widget_cart_item_quantity', 10, 3 );
function ovacrs_woocommerce_widget_cart_item_quantity( $product_quantity,  $cart_item, $cart_item_key ) {

    if( $cart_item['data']->is_type('ovacrs_car_rental') ){
        
        $product_id = $cart_item['product_id'];
        $room_check_in = strtotime( $cart_item['room_check_in'] );
        $room_check_out = strtotime( $cart_item['room_check_out'] );

        return '× '.get_real_quantity( $product_quantity, $product_id, $room_check_in, $room_check_out );     

    }else{

        return $product_quantity;

    }
    
}; 


add_filter( 'woocommerce_cart_item_quantity', 'ovacrs_filter_woocommerce_cart_item_quantity', 10, 3 ); 
function ovacrs_filter_woocommerce_cart_item_quantity( $product_quantity, $cart_item_key, $cart_item ) {

    if( $cart_item['data']->is_type('ovacrs_car_rental') ){
        
        $product_id = $cart_item['product_id'];
        $room_check_in = strtotime( $cart_item['room_check_in'] );
        $room_check_out = strtotime( $cart_item['room_check_out'] );

        return get_real_quantity( $product_quantity, $product_id, $room_check_in, $room_check_out );     

    }else{

        return $product_quantity;

    }
    
}; 



// Filter Price for Cart
add_filter( 'woocommerce_cart_item_price', 'ovacrs_filter_woocommerce_cart_item_price', 10, 3 ); 
function ovacrs_filter_woocommerce_cart_item_price( $product_price, $cart_item, $cart_item_key ) {

    if( $cart_item['data']->is_type('ovacrs_car_rental') ){
        
        $product_id = $cart_item['product_id'];
        $room_check_in = strtotime( $cart_item['room_check_in'] );
        $room_check_out = strtotime( $cart_item['room_check_out'] );

        return get_real_price( $product_price, $product_id, $room_check_in, $room_check_out );
    }else{
        return $product_price;
    }
    

}


// Filter Quantity for Checkout
add_filter( 'woocommerce_checkout_cart_item_quantity', 'ovacrs_woocommerce_checkout_cart_item_quantity', 10, 3 );
function ovacrs_woocommerce_checkout_cart_item_quantity( $product_quantity, $cart_item, $cart_item_key ){

    if( $cart_item['data']->is_type('ovacrs_car_rental') ){
        
        $product_id = $cart_item['product_id'];
        $room_check_in = strtotime( $cart_item['room_check_in'] );
        $room_check_out = strtotime( $cart_item['room_check_out'] );

        return '<span class="ovacrs_qty">'.get_real_quantity( $product_quantity, $product_id, $room_check_in, $room_check_out ).'</span>';     

    }else{

        return '';

    }
    

}





// Filter Quantity for Order detail after checkout
add_filter( 'woocommerce_order_item_quantity_html', 'ovacrs_woocommerce_order_item_quantity_html', 10, 2 ); 
function ovacrs_woocommerce_order_item_quantity_html( $quantity, $item ){
    
    $product_id = $item->get_product_id();
    $product = wc_get_product( $product_id );

    if( $product->is_type( 'ovacrs_car_rental' ) ){

        foreach ( $item->get_formatted_meta_data() as $meta_id => $meta ) {
            if( $meta->key == 'room_check_in' ){
                $room_check_in = strtotime( $meta->value ) ;
            }
            if( $meta->key == 'room_check_out' ){
                $room_check_out = strtotime( $meta->value );
            }
        }

        return '<span class="ovacrs_qty">'.get_real_quantity( $quantity, $product_id, $room_check_in, $room_check_out ).'</span>';
    }

    return $quantity;
    
}




add_filter( 'woocommerce_order_item_display_meta_key', 'ovacrs_change_order_item_meta_title', 20, 3 );

/**
 * Changing a meta title
 * @param  string        $key  The meta key
 * @param  WC_Meta_Data  $meta The meta object
 * @param  WC_Order_Item $item The order item object
 * @return string        The title
 */
function ovacrs_change_order_item_meta_title( $key, $meta, $item ) {
    
    // By using $meta-key we are sure we have the correct one.
    if ( 'room_check_in' === $meta->key ) { $key = esc_html__('Check in', 'ova-hotel'); }
    if ( 'room_check_out' === $meta->key ) { $key = esc_html__('Check out', 'ova-hotel'); }
    if ( 'ovacrs_total_days' === $meta->key ) { $key = esc_html__('Total Nights', 'ova-hotel'); }
    if ( 'ovacrs_price_detail' === $meta->key ) { $key = esc_html__(' Price Detail  ', 'ova-hotel'); }
    if ( 'room_adults' === $meta->key ) { $key = esc_html__('Adults', 'ova-hotel'); }
    if ( 'room_childrens' === $meta->key ) { $key = esc_html__('Childrens', 'ova-hotel'); }
    if ( 'room_rooms' === $meta->key ) { $key = esc_html__('Rooms', 'ova-hotel'); }
    if ( 'id_room_code' === $meta->key ) { $key = esc_html__('Room Code', 'ova-hotel'); }
     
    return $key;
}

add_filter( 'woocommerce_order_item_display_meta_value', 'change_order_item_meta_value', 20, 3 );

/**
 * Changing a meta value
 * @param  string        $value  The meta value
 * @param  WC_Meta_Data  $meta   The meta object
 * @param  WC_Order_Item $item   The order item object
 * @return string        The title
 */
function change_order_item_meta_value( $value, $meta, $item ) {
    
    // By using $meta-key we are sure we have the correct one.
    if ( 'room_check_in' === $meta->key ) { $key = esc_html__('Check in', 'ova-hotel'); }
    if ( 'room_check_out' === $meta->key ) { $key = esc_html__('Check out', 'ova-hotel'); }
    if ( 'ovacrs_total_days' === $meta->key ) { $key = esc_html__('Total Nights', 'ova-hotel'); }
    if ( 'ovacrs_price_detail' === $meta->key ) { $key = esc_html__(' Price Detail  ', 'ova-hotel'); }
    if ( 'room_adults' === $meta->key ) { $key = esc_html__('Adults', 'ova-hotel'); }
    if ( 'room_childrens' === $meta->key ) { $key = esc_html__('Childrens', 'ova-hotel'); }
    if ( 'room_rooms' === $meta->key ) { $key = esc_html__('Rooms', 'ova-hotel'); }
    if ( 'id_room_code' === $meta->key ) { $key = esc_html__('Room Code', 'ova-hotel'); }
     
    return $value;
}


