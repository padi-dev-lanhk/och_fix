<?php $post_id = get_the_ID();

 ?>

<!-- Total Vehicle -->
<?php  woocommerce_wp_text_input(
  array(
   'id'                => 'ovacrs_car_count',
   'class'             => 'short',
   'label'             => __( 'Total Rooms', 'ova-hotel' ),
   'placeholder'       => '',
   'desc_tip'    => 'true',
   'description'       => __( 'Example: Single Room Type has 7 rooms', 'ova-hotel' ),
   'type'              => 'number'
   ));
?>

<!-- ID Vehicles -->
<?php  woocommerce_wp_text_input(
  array(
   'id'                => 'ovacrs_id_vehicles',
   'class'             => 'short',
   'label'             => __( 'Room Code', 'ova-hotel' ),
   'placeholder'       => '101, 102, 102',
   'desc_tip'    => 'true',
   'description'       => __( 'If Total Rooms is 3, you have to insert 3 Room Code : 101, 102, 102 . Note code room is unique', 'ova-hotel' ),
   'type'              => 'text'
   ));
?>



<!-- Adults max -->
<?php  woocommerce_wp_text_input(
  array(
   'id'                => 'ovacrs_car_max_adults',
   'class'             => 'short ',
   'label'             => __( 'Adults Max', 'ova-hotel' ),	
   'placeholder'       => '2',
   'type'              => 'number'
   ));
?>

<!-- Childrens max -->
<?php  woocommerce_wp_text_input(
  array(
   'id'                => 'ovacrs_car_max_childrens',
   'class'             => 'short ',
   'label'             => __( 'Childrens Max', 'ova-hotel' ),	
   'placeholder'       => '2',
   'type'              => 'number'
   ));
?>

<!-- Capacity max -->
<?php  woocommerce_wp_text_input(
  array(
   'id'                => 'ovacrs_car_acreage',
   'class'             => 'short ',
   'label'             => __( 'Acreage', 'ova-hotel' ),	
   'placeholder'       => '24m2',
   'type'              => 'text'
   ));
?>

<!-- Video Link -->
<?php woocommerce_wp_text_input(
  array(
   'id'                => 'ovacrs_video_link',
   'class'             => 'short ',
   'label'             => esc_html__( 'Youtute Link', 'ova-hotel' ),
   'placeholder'		=> esc_html__( 'https://www.youtube.com/watch?v=V89uzH3oqxY&width=800&height=488', 'ova-hotel' ),
   'description'       => esc_html__( 'Insert youtube link like: https://www.youtube.com/watch?v=V89uzH3oqxY&width=800&height=488', 'ova-hotel' ),
   'desc_tip'    => 'true',
   'type'              => 'text'
)); ?>

<?php 
// Rent Day min
woocommerce_wp_text_input(
  array(
   'id'                => 'ovacrs_rent_day_min',
   'class'             => 'short ',
   'label'             => esc_html__( 'Min Rental Time', 'ova-hotel' ),
   'placeholder'       => esc_html__( '1', 'ova-hotel' ),
   'type'              => 'number'
));
?>

<?php  woocommerce_wp_text_input(
  array(
   'id'                => 'ovacrs_car_order',
   'class'             => 'short ',
   'label'             => __( 'Order at frontend', 'ova-hotel' ),
   'placeholder'       => '1',
   'desc_tip'    	   => 'true',
   'description'       => __( 'Display in Archive Rooms', 'ova-hotel' ),
   'type'              => 'number'
   ));
?>

	
<div class="options_group show_if_ovacrs_car_rental">

	<div class="ova_panel">
		<div class="ova_panel_title">
			<div class="button"><?php esc_html_e( 'Setup Extra Price', 'ova-hotel' ); ?></div>
		</div>
		<div class="ova_panel_content" style="display: none;">
			<!-- Global Discount -->
			<div class="ovacrs-form-field ">
		  		<br/><strong class="ovacrs_heading_section"><?php esc_html_e(' GLOBAL DISCOUNT (GD)', 'ova-hotel'); ?></strong>
		  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_global_discount.php' ); ?>
			</div>



			<!-- Price by range time -->
			<div class="ovacrs-form-field ">
				<br/><strong class="ovacrs_heading_section"><?php esc_html_e('SPECIAL TIME (ST)', 'ova-hotel'); ?></strong>
				<span class="ovacrs_right"><?php esc_html_e( 'Note: ST doesnt use GD, it will use PST', 'ova-hotel' ); ?></span>
				<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_rt.php' ); ?>
			</div>	
		</div>
	</div>
	
	
	<div class="ova_panel">
		<div class="ova_panel_title">
			<div class="button"><?php esc_html_e( 'Special Info', 'ova-hotel' ); ?></div>
		</div>
		<div class="ova_panel_content" style="display: none;">
			
			<!-- Feature -->
			<div class="ovacrs-form-field ">
		  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_special.php' ); ?>
			</div>

		</div>
	</div>

	<div class="ova_panel">
		<div class="ova_panel_title">
			<div class="button"><?php esc_html_e( 'AMENITIES', 'ova-hotel' ); ?></div>
		</div>
		<div class="ova_panel_content" style="display: none;">
			
			<!-- Feature -->
			<div class="ovacrs-form-field ">
		  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_features.php' ); ?>
			</div>

		</div>
	</div>


	
	<div class="ova_panel">
		<div class="ova_panel_title">
			<div class="button"><?php esc_html_e( 'SERVICES', 'ova-hotel' ); ?></div>
		</div>
		<div class="ova_panel_content" style="display: none;">
			
			<!-- Feature -->
			<div class="ovacrs-form-field ">
		  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_resources.php' ); ?>
			</div>

		</div>
	</div>
	

	<div class="ova_panel">
		<div class="ova_panel_title">
			<div class="button"><?php esc_html_e( 'UNAVAILABLE TIME (UT)', 'ova-hotel' ); ?></div>
		</div>
		<div class="ova_panel_content" style="display: none;">
			
			<!-- unavailable time -->
			<div class="ovacrs-form-field ">
		  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_untime.php' ); ?>
			</div>

		</div>
	</div>




</div>