<div class="ovacrs_specials">
	<table class="widefat">

		<thead>
			<tr>
				<th><?php esc_html_e( 'Icon Class', 'ova-hotel' ); ?></th>
				<th><?php esc_html_e( 'Label', 'ova-hotel' ); ?></th>
				<th><?php esc_html_e( 'Featured', 'ova-hotel' ); ?></th>
			</tr>
		</thead>

		<tbody class="wrap_rt_spcecial">
			<!-- Append html here -->
			<?php if( $ovacrs_specials_label = get_post_meta( $post_id, 'ovacrs_specials_label', 'false' ) ){

					$ovacrs_specials_icon = get_post_meta( $post_id, 'ovacrs_specials_icon', 'false' );
					$ovacrs_specials_featured = get_post_meta( $post_id, 'ovacrs_specials_featured', 'false' );

					for( $i = 0 ; $i < count( $ovacrs_specials_label ); $i++ ) {
			?>

				<tr class="tr_rt_special">

					<td width="30%">
				      <input type="text" name="ovacrs_specials_icon[]" placeholder="<?php esc_html_e( 'Icon', 'ova-hotel' ); ?>" value="<?php echo $ovacrs_specials_icon[$i]; ?>" />
				    </td>					

				    <td width="40%">
				      <input type="text" name="ovacrs_specials_label[]" placeholder="<?php esc_html_e( 'Label', 'ova-hotel' ); ?>" value="<?php echo $ovacrs_specials_label[$i]; ?>" />
				    </td>

				    <td width="19%">
				      <select  name="ovacrs_specials_featured[]" class="short_dura">
				    		<option value="yes" <?php echo $ovacrs_specials_featured[$i] == 'yes' ? 'selected': ''; ?> ><?php esc_html_e( 'Yes', 'ova-hotel' ); ?></option>
				    		<option value="no" <?php echo $ovacrs_specials_featured[$i] == 'no' ? 'selected': ''; ?> ><?php esc_html_e( 'No', 'ova-hotel' ); ?></option>
				    	</select>
				    </td>

				    <td width="10%"><a href="#" class="delete_special">x</a></td>
				    
				</tr>

			<?php } } ?>
		</tbody>

		<tfoot>
			<tr>
				<th colspan="6">
					<a href="#" class="button insert_rt_special" data-row="
						<?php
							ob_start();
							include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_special_field.php' );
							echo esc_attr( ob_get_clean() );
						?>

					">
					<?php esc_html_e( 'Add Special', 'ova-hotel' ); ?></a>
					</a>

					
				</th>
			</tr>
		</tfoot>

	</table>
</div>


