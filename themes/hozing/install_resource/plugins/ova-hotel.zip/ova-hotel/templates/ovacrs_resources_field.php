<tr class="tr_rt_resource">

   

    <td width="48%">
      <input type="text" name="ovacrs_resource_name[]" value="" />
    </td>

  
    <td width="48%">
      <input type="text" name="ovacrs_resource_price[]" value="" />
    </td>

   

    <td width="1%"><a href="#" class="delete_resource">x</a></td>
    
</tr>