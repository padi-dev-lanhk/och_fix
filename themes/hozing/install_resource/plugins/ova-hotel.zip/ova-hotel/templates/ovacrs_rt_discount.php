<table class="wrap_rt_discount">
	<tbody>
		<tr class="tr_rt_discount">
									
		    <td width="11%">
		        <input type="text" class="ovacrs_rt_discount_price input_per_100" placeholder="<?php esc_html_e('Price', 'ova-hotel'); ?>"
		               name="ovacrs_rt_discount[ovacrs_key][price][]" value="" />
		    </td>

		    <td width="26%">
			    
			      <input type="text" class="input_text short ovacrs_rt_discount_duration" placeholder="<?php esc_html_e('Insert number', 'ova-hotel'); ?>"
			             name="ovacrs_rt_discount[ovacrs_key][duration][]" value=""/>


			    
		    </td>
		    <td width="1%"><a href="#" class="delete_discount">x</a></td>
		    
		</tr>
	</tbody>
</table>
