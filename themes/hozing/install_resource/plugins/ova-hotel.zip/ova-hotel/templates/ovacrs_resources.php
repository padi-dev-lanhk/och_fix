<div class="ovacrs_resources">
	<table class="widefat">

		<thead>
			<tr>
				<th><?php esc_html_e( 'Name', 'ova-hotel' ); ?></th>
				<th><?php esc_html_e( 'Price', 'ova-hotel' ); ?></th>
			</tr>
		</thead>

		<tbody class="wrap_resources">
			<!-- Append html here -->
			<?php if( $ovacrs_resource_name = get_post_meta( $post_id, 'ovacrs_resource_name', 'false' ) ){ 
					
					$ovacrs_resource_price = get_post_meta( $post_id, 'ovacrs_resource_price', 'false' );

					
					

					for( $i = 0 ; $i < count( $ovacrs_resource_name ); $i++ ) {
			?>

				<tr class="tr_rt_resource">

				

				    <td width="48%">
				      <input type="text" name="ovacrs_resource_name[]"  value="<?php echo $ovacrs_resource_name[$i]; ?>" />
				    </td>

				    <td width="48%">
				      <input type="text"  name="ovacrs_resource_price[]"  value="<?php echo $ovacrs_resource_price[$i]; ?>" />
				    </td>

				    
				    <td width="1%"><a href="#" class="delete_resource">x</a></td>
				    
				</tr>

			<?php } } ?>
		</tbody>

		<tfoot>
			<tr>
				<th colspan="6">
					<a href="#" class="button insert_resources" data-row="
						<?php
							ob_start();
							include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_resources_field.php' );
							echo esc_attr( ob_get_clean() );
						?>

					">
					<?php esc_html_e( 'Add Service', 'ova-hotel' ); ?></a>
					</a>

					
				</th>
			</tr>
		</tfoot>

	</table>
</div>


