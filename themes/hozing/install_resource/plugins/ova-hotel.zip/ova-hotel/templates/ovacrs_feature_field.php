<tr class="tr_rt_feature">

    <td width="30%">
      <input type="text" name="ovacrs_features_icons[]" placeholder="<?php esc_html_e( 'Font-Awesome', 'ova-hotel' ); ?>" value="" />
    </td>

    <td width="40%">
      <input type="text" name="ovacrs_features_label[]" placeholder="<?php esc_html_e( 'Label', 'ova-hotel' ); ?>" value="" />
    </td>


    <td width="19%">
      <select  name="ovacrs_features_special[]" class="short_dura">
    		<option value="yes" ><?php esc_html_e( 'Yes', 'ova-hotel' ); ?></option>
    		<option value="no"  ><?php esc_html_e( 'No', 'ova-hotel' ); ?></option>
    	</select>
    </td>

    <td width="1%"><a href="#" class="delete_feature">x</a></td>
    
</tr>