<div class="ovacrs_global_discount">
	<table class="widefat">

		<thead>
			<tr>
				<th><?php esc_html_e( 'Price ($)', 'ova-hotel' ); ?></th>
				<th><?php esc_html_e( 'Length of Stay (Night)', 'ova-hotel' ); ?></th>
			</tr>
		</thead>

		<tbody>
			<!-- Append html here -->

			<?php if( $ovacrs_global_discount_price = get_post_meta( $post_id, 'ovacrs_global_discount_price', 'false' ) ){

				$ovacrs_global_discount_duration_val = get_post_meta( $post_id, 'ovacrs_global_discount_duration_val', 'false' );
				

				for( $i =0 ; $i < count( $ovacrs_global_discount_price ); $i++ ) { ?>
					<tr class="row_discount">
							
					    <td width="11%">
					        <input type="text" class="input_text" placeholder="<?php esc_html_e('Price', 'ova-hotel'); ?>"
					               name="ovacrs_global_discount_price[]" value="<?php echo $ovacrs_global_discount_price[$i]; ?>"/>
					    </td>

					    <td width="26%">
						    
						      <input type="text" class="input_text short" placeholder="<?php esc_html_e('Insert number', 'ova-hotel'); ?>"
						             name="ovacrs_global_discount_duration_val[]" value="<?php echo $ovacrs_global_discount_duration_val[$i]; ?>"/>


						   
						    
					    </td>
					    <td width="1%"><a href="#" class="delete">x</a></td>
					    
					</tr>
				<?php }

			} ?>
		</tbody>

		<tfoot>
			<tr>
				<th colspan="6">
					<a href="#" class="button insert_discount" data-row="<tr class=&quot;row_discount&quot;>
					    <td width=&quot;11%&quot;>
					        <input type=&quot;text&quot; class=&quot;input_text&quot; placeholder=&quot;<?php esc_html_e('Price', 'ova-hotel'); ?>&quot;
					               name=&quot;ovacrs_global_discount_price[]&quot; value=&quot;&quot;/>
					    </td>

					    <td width=&quot;26%&quot;>
					    
					      <input type=&quot;text&quot; class=&quot;input_text short&quot; placeholder=&quot;<?php esc_html_e('Insert number', 'ova-hotel'); ?>&quot; name=&quot;ovacrs_global_discount_duration_val[]&quot; value=&quot;&quot;/>

					      
					    
					    </td>

					    <td width=&quot;1%&quot;><a href=&quot;#&quot; class=&quot;delete&quot;>x</a></td>

					</tr>


					"><?php esc_html_e( 'Add PD', 'ova-hotel' ); ?></a>
				</th>
			</tr>
		</tfoot>

	</table>
</div>