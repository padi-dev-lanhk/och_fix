<tr class="tr_rt_other_feature">

    <td width="90%">
      <input type="text" name="ovacrs_other_features_name[]" placeholder="<?php esc_html_e( 'Name', 'ova-hotel' ); ?>" value="" />
    </td>

    <td width="10%"><a href="#" class="delete_other_feature">x</a></td>
    
</tr>