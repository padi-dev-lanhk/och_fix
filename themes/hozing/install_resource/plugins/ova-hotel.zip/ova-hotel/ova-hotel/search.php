<?php if ( !defined( 'ABSPATH' ) ) { exit; }

get_header( 'archive-hotel' );
?>
<?php 
	$templ_search = get_theme_mod( 'rl_search_tempale', 'true' ) ? get_theme_mod( 'rl_search_tempale', 'true' ) : '2columns_no_sidebar1'; ?>
<div class="wrap_site archive_rental">
	
	<div class="hozing_wd_search">
		<?php echo do_shortcode( '[ovahotel_search /]' ); ?>
	</div>

<?php 
global $count;

$count = 0;

$rooms = ovacrs_search_rooms( $_GET ); 
if( $rooms != false){
?>

<div id="main-content-woo" class="main"><div class="row row-m10 <?php if( $templ_search == '2columns_no_sidebar1' ){echo 'room-grid-2-columns-v1';} elseif ( $templ_search == '2columns_no_sidebar2' ){echo 'room-grid-2-columns-v2';} elseif ( $templ_search == '2columns_sidebar'){echo 'room-grid-2-columns-with-sidebar';} elseif( $templ_search == 'room_list_with_sidebar'){echo 'room-list-with-sidebar';} elseif( $templ_search == '3columns_no_sidebar1'){echo 'room-grid-3-columns-v1';}elseif( $templ_search == '3columns_no_sidebar2'){echo 'room-grid-3-columns-v2';}elseif( $templ_search == 'room_list'){echo 'room-list';}elseif($templ_search == 'room_lifestyle'){ echo 'room-life';}?>">
	<?php if ( $rooms->have_posts() ) : while ( $rooms->have_posts() ) : $rooms->the_post();


		if( $templ_search == '2columns_sidebar'){

			wc_get_template_part( 'hotel/content-product_2columns_sidebar' );

		} elseif( $templ_search == 'room_list_with_sidebar') {

			wc_get_template_part( 'hotel/content-product_room_list_with_sidebar' );

		} elseif( $templ_search == '2columns_no_sidebar1') {

			wc_get_template_part( 'hotel/content-product_2columns_no_sidebar1');

		} elseif( $templ_search == '2columns_no_sidebar2'){

			wc_get_template_part( 'hotel/content-product_2columns_no_sidebar2');

		} elseif( $templ_search == '3columns_no_sidebar1') {

			wc_get_template_part( 'hotel/content-product_3columns_no_sidebar1');

		} elseif( $templ_search == '3columns_no_sidebar2'){

			wc_get_template_part( 'hotel/content-product_3columns_no_sidebar2');

		} elseif( $templ_search == 'room_list'){

			wc_get_template_part( 'hotel/content-product_room_list');

		} elseif( $templ_search == 'room_lifestyle'){

			wc_get_template_part( 'hotel/content-product_room_lifestyle');

		}

		$count++;

	endwhile; ?>

		
		
			<?php 

			$big = 999999999; // need an unlikely integer

			$args = array(
				'base'               => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
				'format'             => '?paged=%#%',
				'current' 			=> max( 1, get_query_var('paged') ),
				'total' 			=> $rooms->max_num_pages,
				'show_all'           => false,
				'end_size'           => 1,
				'mid_size'           => 2,
				'prev_next'          => true,
				'prev_text'          => '<i class="arrow_carrot-left"></i>',
				'next_text'          => '<i class="arrow_carrot-right"></i>',
				'type'               => 'list',
				'add_args'           => false,
				'add_fragment'       => '',
				'before_page_number' => '',
				'after_page_number'  => ''
			);
			if( paginate_links( $args ) ) :
				echo '<nav class="woocommerce-pagination">';
				echo paginate_links( $args );
				echo '</nav>';
			endif;
		 	?>
			
	<?php else :
		esc_html_e( 'Not Found', 'ova-hotel' );
	endif; wp_reset_postdata();
	?>

</div></div>

<?php }else{ ?>
	<div id="main-content-woo" class="main" style="padding-bottom: 87px;">
	<?php esc_html_e( 'Not Found Any Rooms', 'ova-hotel' ); ?>
	</div>
<?php } ?>
<?php get_sidebar('shop'); ?>
</div>

<?php 
get_footer('archive-hotel');